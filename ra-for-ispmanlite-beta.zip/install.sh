#!/bin/bash

ROOT=`pwd`

if [ "${ROOT}" == "/" ]; then
    echo "Cannot be executed in the root folder."
    exit;
fi

cp -rf usr/* /usr
cp -rf etc/* /etc
cp -f etc/cron.d/revisium /etc/cron.d/revisium

mkdir -p /usr/local/mgr5/var/raisp_data
mkdir -p /usr/local/mgr5/var/raisp_data/log
mkdir -p /usr/local/mgr5/var/raisp_data/tmp
mkdir -p /usr/local/mgr5/var/raisp_data/data
mkdir -p /usr/local/mgr5/var/raisp_data/db
mkdir -p /usr/local/mgr5/var/raisp_data/lists
mkdir -p /usr/local/mgr5/var/raisp_data/lock
mkdir -p /usr/local/mgr5/var/raisp_data/result
mkdir -p /usr/local/mgr5/var/raisp_data/backups
mkdir -p /usr/local/mgr5/var/raisp_data/cache
mkdir -p /usr/local/mgr5/var/raisp_data/cache/queue
mkdir -p /usr/local/mgr5/var/raisp_data/cache/tasks

chmod 777 /usr/local/mgr5/var/raisp_data/tmp
chmod 777 /usr/local/mgr5/var/raisp_data/result
chmod 777 /usr/local/mgr5/var/raisp_data/backups

cp -f uninstall.sh /usr/local/mgr5/addon/revisium_antivirus/

ps ax | grep "scafore/queue.php" | grep -v "grep" | awk '{system("kill -9 " $1)}'
ps ax | grep "revisium_antivirus/services/queue.php" | grep -v "grep" | awk '{system("kill -9 " $1)}'

/opt/php71/bin/php -c /usr/local/mgr5/addon/revisium_antivirus/php.ini /usr/local/mgr5/addon/revisium_antivirus/services/migrations.php
find /usr/local/mgr5/var/ra_data -delete 2>/dev/null
find /usr/local/mgr5/var/scafore -delete 2>/dev/null

/opt/php71/bin/php -c /usr/local/mgr5/addon/revisium_antivirus/php.ini /usr/local/mgr5/addon/revisium_antivirus/services/queue.php >> /usr/local/mgr5/var/raisp_data/log/raisp_queue.log 2>&1 &

#/usr/local/mgr5/sbin/mgrctl -m ispmgr exit;

echo "Good news, Revisium Antivirus has been successfully installed. Open the ISP Manager and check it under Revisium Antivirus menu" 