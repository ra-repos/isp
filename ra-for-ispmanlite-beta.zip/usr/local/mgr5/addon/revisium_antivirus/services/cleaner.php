<?php

include_once __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'common.php';

\RAISP\Application::offSTDIN();

\framework\Cleaner::cleanupAndRotate($rotated, $deleted);

$count_deleted = \scaforeSDK\BackupHelper::serviceAllBackups(\RAISP\Application::getKeepBackup());

\framework\Log::info('SR---CL - rotated: ' . $rotated . ' deleted: ' . $deleted . ' deleted backups: ' . $count_deleted);