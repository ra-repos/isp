<?php

include_once __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'common.php';

use \RAISP\Application;
use \RAISP\Log;

Application::offSTDIN();

Log::info('SR---UPT - Check for updates');
$latest_version = trim(@file_get_contents('https://raw.githubusercontent.com/ra-repos/isp/master/latest-version.txt?' . rand(1,99999)));
$current_version = Application::getVersion();


Log::info('SR---UPT - versions = [' . $latest_version . '] vs [' . $current_version . ']');

if (version_compare($latest_version, $current_version) >= 1) {
    Log::info('SR---UPT - Get latest');
    @exec('wget -O - https://raw.githubusercontent.com/ra-repos/isp/master/install.sh | bash', $output, $return);
    if (!$return) {
        Log::info('SR---UPT - Done');
    } else {
        Log::info('SR---UPT - Failed with status [' . $return . ']');
    }
} else {
    Log::info('SR---UPT - current version is the latest');
}
