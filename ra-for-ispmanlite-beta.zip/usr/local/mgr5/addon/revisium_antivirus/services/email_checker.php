<?php

include_once __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'common.php';

use \RAISP\Application;
use \RAISP\Log;

Application::offSTDIN();

$lang = isset($argv[1]) ? $argv[1] : '';
if (!empty($lang)) {
    Application::setLang($lang);
}

Log::info('SR---EMC - email_checker.php: run email check with lang: ' . Application::getLang());

if (\RAISP\EmailChecker::sendEmail()) {
    Log::err('SR---EMC - cannot send email');
    exit(0);
}
exit(1);