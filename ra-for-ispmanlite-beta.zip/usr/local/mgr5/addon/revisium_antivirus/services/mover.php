<?php

define('STATUS_WORKING' , 'working');
define('STATUS_DONE'    , 'done');

$username           = isset($argv[1]) ? $argv[1] : false;
$from_folder        = isset($argv[2]) ? $argv[2] : false;
$to_folder          = isset($argv[3]) ? $argv[3] : false;
$file_with_list     = isset($argv[4]) ? $argv[4] : false;
$progress_filepath  = isset($argv[5]) ? $argv[5] : false;

if ($from_folder === false 
        || $to_folder === false 
        || $file_with_list === false 
        || $progress_filepath === false
) {
    exit;
}

if (!empty($username)) {
    $info = posix_getpwnam($username);
    if ($info !== false) {
        posix_setgid($info['gid']);
        posix_setuid($info['uid']);    
    }
}

$created_dirs   = [];
$files_list     = getFilesList($file_with_list);
$all_cnt        = count($files_list);
$i              = 0;
$last_time      = 0;

foreach ($files_list as $fil_sub_path)
{
    if ($i % 10 == 0 && time() - $last_time > 1) {
        $last_time = time();
        updateProcessLog($progress_filepath, round($i / $all_cnt * 100, 2), STATUS_WORKING);
    }
    $i++;
    moveFile($from_folder, $to_folder, $fil_sub_path);
}

updateProcessLog($progress_filepath, 100, STATUS_DONE);

// =============================

function getFilesList($filepath)
{
    if (!file_exists($filepath)) {
        return [];
    }
    $content = file_get_contents($filepath);
    $content = trim($content, " \n\r\t");
    return explode("\n", $content);
}

function updateProcessLog($progress_filepath, $percent, $status)
{
    file_put_contents($progress_filepath, $percent . '|' . $status, LOCK_EX);
}

function moveFile($from_dir, $to_dir, $file_sub_path)
{
    createFoldersStructure($to_dir, $file_sub_path);
    copy($from_dir . DIRECTORY_SEPARATOR . $file_sub_path, $to_dir . DIRECTORY_SEPARATOR . $file_sub_path);
}

function createFoldersStructure($start_dir, $file_sub_path)
{
    global $created_dirs;
    $sub_dirs = explode(DIRECTORY_SEPARATOR, removeFirstSlash($file_sub_path));
    array_pop($sub_dirs);
    $current_folder = removeLastSlash($start_dir);
    foreach ($sub_dirs as $folder)
    {
        $current_folder .= DIRECTORY_SEPARATOR . $folder;
        if (isset($created_dirs[$current_folder])) {
            continue;
        }
        $created_dirs[$current_folder] = true;
        if (file_exists($current_folder)) {
            continue;
        }
        mkdir($current_folder);
    }
}

function removeLastSlash($dir)
{
    return substr($dir, -1) == DIRECTORY_SEPARATOR ? substr($dir, 0, -1) : $dir;
}

function removeFirstSlash($dir)
{
    return substr($dir, 0, 1) == DIRECTORY_SEPARATOR ? substr($dir, 1) : $dir;
}
