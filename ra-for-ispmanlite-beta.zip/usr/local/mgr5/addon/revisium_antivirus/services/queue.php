<?php
include_once __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'common.php';

if (!\framework\Locker::lock('queue')) {
    exit;
}

\framework\Log::info('SR---Q start queue.php');

$start_time             = time();
$period_update_vars     = 10;
$period_check_old_tasks = 60;

$num_threads    = \RAISP\Application::getNumOfThreads();
$queue_timeout  = \RAISP\Application::getQueueTimeout();
$worker_timeout = \RAISP\Application::getWorkingTimeout();

$i = 0;
while(true)
{
    if ($i % $period_update_vars == 0) {
        \RAISP\Application::recacheKeyValueStorage();
        $num_threads = \RAISP\Application::getNumOfThreads();
    }
    if ($i % $period_check_old_tasks == 0) {
        $cleanup_old_tasks = false;
    }
    $server_busy_count = \scaforeSDK\Task\TaskManager::service($num_threads, $cleanup_old_tasks, $queue_timeout, $worker_timeout);
    sleep(1);
    $i++;
    if (!$server_busy_count && time() % 60 > 50 && time() - $start_time > 23 * 60 * 60) {
        break;
    }
}

\framework\Locker::unlock('queue');
\framework\Log::info('SR---Q stop queue.php');
