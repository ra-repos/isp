<?php

include_once __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'common.php';

use \RAISP\Application;
use \RAISP\Log;

Application::offSTDIN();

if (!Application::hasLicense()) {
    Log::info('SR---S - scheduler.php: no have license!');
    exit;
}

$auto_scan_period = Application::getPeriod();
if ($auto_scan_period == -1) {
    exit;
}

$scheduler_counter  = \framework\KeyValueStorage::get('scheduler_counter', 1);
$scheduler_hour     = Application::getStartAt();

if (intval($scheduler_hour) != intval(date('H'))) {
    Log::info('SR---S - scheduler.php: scheduler hour skip');
    exit;
}

$need_exit = true;
if ($scheduler_counter % $auto_scan_period == 0) {
    $need_exit = false;
}

\framework\KeyValueStorage::set('scheduler_counter', $scheduler_counter + 1);

if ($need_exit) {
    Log::info('SR---S - scheduler.php: scheduler period skip');
    exit;
}

Log::info('SR---S - scheduler.php: run all auto scan');

if (Application::getAppMode() == Application::MODE_BY_DOMAIN) {
    $ra_folders = \RAISP\Domain::getAllDomain(true);
}
else {
    $ra_folders = \RAISP\Client::getAllClients(true);
}
foreach ($ra_folders as $ra_folder) 
{
    \RAISP\ScaforeTaskHelper::startScan($ra_folder);
}

Application::setNeedSendNotification(true);