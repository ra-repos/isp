<?php

$have_license   = haveLicense();
$domains        = getDomains();
$clients        = getClients();
$admin_folder   = searchAdminFolder();

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Migrations from 1.4 to 1.5 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
$old_backup_dir = '/usr/local/mgr5/var/scafore/backups';
if ($have_license && file_exists($old_backup_dir)) {
    echo "Running migration from 1.4 to 1.5...\n";
    foreach ($domains as $domain_params)
    {
        $domain     = $domain_params['domain'];
        $username   = $domain_params['username'];
        $path       = $domain_params['path'];
    
        $last_dir           = '/usr/local/mgr5/var/scafore/backups/' . sha1($path);
        $main_backup_dir    = '/var/www/' . $username . '/revisium_antivirus1.4_backup';
        if ($admin_folder) {
            $main_backup_dir = $admin_folder . '/revisium_antivirus1.4_backup/' . $username;
        }
        $full_backup_dir    = $main_backup_dir . '/by_domains/' . $domain;
        if (!file_exists($last_dir)) {
            continue;
        }
        @mkdir($full_backup_dir, 0777, true);
        @chmod($full_backup_dir, 0777);
        @rename($last_dir, $full_backup_dir);
        echo "Backup folder for username: $username and domain: $domain saved!\n";
    }
    foreach ($clients as $client_params)
    {
        $username   = $client_params['username'];
        $path       = $client_params['path'];
    
        $last_dir           = '/usr/local/mgr5/var/scafore/backups/' . sha1($path);
        $main_backup_dir    = '/var/www/' . $username . '/data/revisium_antivirus1.4_backup';
        if ($admin_folder) {
            $main_backup_dir = $admin_folder . '/revisium_antivirus1.4_backup/' . $username;
        }
        $full_backup_dir    = $main_backup_dir . '/by_users/';
    
        if (!file_exists($last_dir)) {
            continue;
        }
        @mkdir($full_backup_dir, 0777, true);
        @chmod($full_backup_dir, 0777);
        @rename($last_dir, $full_backup_dir);
        echo "Backup folder for username: $username saved!\n";
    }
}
else {
    echo "Skip migration from 1.4 to 1.5. Noting to do.\n";
}

// ===========================================================

function haveLicense()
{
    $license = 'Module: RevisiumAntivirus';
    @exec('/usr/local/mgr5/sbin/licctl info /usr/local/mgr5/etc/ispmgr.lic', $result);
    $content = implode("\n", $result);
    if (strpos($content, $license) !== false) {
        return true;
    }
    return false;
}

function getDomains()
{
    exec('/usr/local/mgr5/sbin/mgrctl -m ispmgr webdomain', $result);
    $domains = [];
    foreach ($result as $line)
    {
        $domain_params  = [];
        $params         = preg_split('~\s(\S+)=~', ' ' . $line, -1, PREG_SPLIT_DELIM_CAPTURE);
        $key            = '';
        array_shift($params);
        for($i = 0; $i < count($params); $i++)
        {
            if ($i % 2 == 0) {
                $key = $params[$i];
            }
            else {
                $domain_params[$key] = $params[$i];
            }
        }
        $domains[] = [
            'domain'    => $domain_params['name'],
            'username'  => $domain_params['owner'],
            'path'      => $domain_params['docroot'],
        ];
    }
    return $domains;
}

function getClients()
{
    $domains = getDomains();
    $clients = [];
    foreach ($domains as $domain)
    {
        $username           = $domain['username'];
        $clients[$username] = [
            'username'  => $username,
            'path'      => preg_replace('~/[^/]+/[^/]+$~', '', $domain['path']),
        ];
    }
    return $clients;
}

function searchAdminFolder()
{
    $folders = [
        '/var/www/admin',
        '/root',
    ];
    foreach ($folders as $folder)
    {
        if (file_exists($folder)) {
            return $folder;
        }
    }
    return false;
}
