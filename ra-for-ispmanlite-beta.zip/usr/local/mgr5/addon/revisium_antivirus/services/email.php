<?php

// need run once in 5 minutes

include_once __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'common.php';

use \RAISP\Application;
use \RAISP\Log;

Application::offSTDIN();

if (!Application::hasLicense()) {
    Log::info('SR---EM - send_notification.php: have no license!');
    exit;
}

if (!Application::getNeedSendNotification()) {
    Log::info('SR---EM - send_notification.php: skiped');
    exit;
}

$email = \RAISP\EmailFactory::getEMail();

if (!$email) {
    Log::info('SR---EM - send_notification.php: not found params for send email');
    Application::setNeedSendNotification(false);
    exit;
}

$notification_message = new \RAISP\NotificationBuilder(false);

if ($notification_message->haveWorkingDomains()) {
    exit;
}

if ($notification_message->haveMessage()) {
    $subject    = $notification_message->getSubject();
    $text       = $notification_message->getText();

    $email->setEmail(Application::getEmail());
    $email->setSubject($subject);
    $email->setText($text);
    if ($email->send()) {
        Log::info('SR---EM - send_notification.php: sent email');
    }
    else {
        Log::info('SR---EM - send_notification.php: error sending email');
    }
}

Application::setNeedSendNotification(false);

