<?php

include_once __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'common.php';

$task_id    = $argv[1];
if (!\framework\Filter::validateHash($task_id)) {
    \framework\Log::err('SR---TE - not valid task_id:' . $task_id);
    exit;
}
$task       = \scaforeSDK\Task\Task::getInstance($task_id);
if (!$task) {
    \framework\Log::err('SR---TE - cannot load task_id:' . $task_id);
    exit;
}
$task->run();

