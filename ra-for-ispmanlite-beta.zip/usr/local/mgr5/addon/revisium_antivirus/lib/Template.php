<?php

namespace RAISP;

class Template
{
    private $template_name          = '';
    private $params                 = [];
    private $condition_blocks       = [];
    private static $template_folder = '/tmp';
    
    public function __construct($template_name) 
    {
        $this->template_name = $template_name;
    }
    
    public static function setFolder($folder)
    {
        self::$template_folder = $folder;
    }
    
    public function setParam($param_name, $param_value)
    {
        $this->params[$param_name] = $param_value;
    }
    
    public function setParams($params)
    {
        foreach ($params as $name => $value)
        {
            $this->params[$name] = $value;
        }
    }
    
    public function setConditionBlock($name, $value)
    {
        $this->condition_blocks[$name] = $value;
    }

    public function build()
    {
        $template_filepath = self::$template_folder . DIRECTORY_SEPARATOR . $this->template_name . '.xml';
        if (!file_exists($template_filepath)) {
            Log::err('RA--T-B - build: Not found template name:' . $this->template_name);
            return '';
        }
        $this->result_xml = file_get_contents($template_filepath);
        $this->replaceBlocks();
        $this->replaceParams();
        $this->replaceLocaleTitle();
        return $this->result_xml;
    }
    
    public function getTamplateFilePath($template_name = null)
    {
        if (is_null($template_name)) {
            $template_name = $this->template_name;
        }
        return self::$template_folder . DIRECTORY_SEPARATOR . $template_name . '.xml';
    }
    
    // ===============================
    
    private function replaceBlocks()
    {
        $replace = function($matches){
            $block = $matches[1];
            if (substr($block, 0, 1) == '?') {
                $index = substr($block, 1);
                $block = isset($this->condition_blocks[$index]) ? $this->condition_blocks[$index] : '';
            }
            $template_filepath = $this->getTamplateFilePath($block);
            if (file_exists($template_filepath)) {
                return file_get_contents($template_filepath);
            }
            return '';
        };
        
        $done = 1;
        while($done) 
        {
            $this->result_xml = preg_replace_callback('/##([^#\s]+)##/', $replace, $this->result_xml, -1, $done);
        }
    }

    private function replaceParams()
    {
        foreach ($this->params as $param_name => $param_value)
        {
            $this->result_xml = str_replace('@@' . $param_name . '@@', $param_value, $this->result_xml);
        }
    }
    
    private function replaceLocaleTitle() 
    {
        $this->result_xml = preg_replace_callback('/@@([^@]+)@@/', 
            function($matches)
            {
                $index = $matches[1];
                if (Locale::checkKey($index)) {
                    return Locale::getMessage($index);
                }
                return '[[' . $index . ']]';
            }
        , $this->result_xml);
    }
}