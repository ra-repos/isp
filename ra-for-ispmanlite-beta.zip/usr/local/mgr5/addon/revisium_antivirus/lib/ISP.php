<?php

namespace RAISP;

class ISP
{
    public static function runCommand($command)
    {
        exec($command, $result, $code);
        $params = [];
        foreach ($result as $line)
        {
            $params[] = self::parseLineResult($line);
        }
        return $params;
    }
    
    // ======================================================
    private static function parseLineResult($line)
    {
        $result = [];
        $params = preg_split('~\s(\S+)=~', ' ' . $line, -1, PREG_SPLIT_DELIM_CAPTURE);
        $key    = '';
        array_shift($params);
        for($i = 0; $i < count($params); $i++)
        {
            if ($i % 2 == 0) {
                $key = $params[$i];
            }
            else {
                $result[$key] = $params[$i];
            }
        }
        return $result;
    }
 
}