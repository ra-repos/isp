<?php

namespace RAISP;

class KeyValueStorage extends \framework\KeyValueStorage
{
    
}