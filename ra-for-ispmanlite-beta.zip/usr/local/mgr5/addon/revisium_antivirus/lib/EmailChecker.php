<?php

namespace RAISP;

class EmailChecker
{
    const MAIL_ERROR_MARKER = '%4un3@1S%';
    
    private static $checker_script_filepath = '';
    
    public static function setCheckerScriptFilepth($checker_script_filepath)
    {
        self::$checker_script_filepath = $checker_script_filepath;
    }

    public static function sendEmailWithCheck()
    {
        $cmd = Application::getPHPHandler() . ' -c ' . Application::getPHPIniPath() . ' ' . self::$checker_script_filepath . ' ' . escapeshellarg(Application::getLang()) . ' >> /tmp/out 2>&1';
        
        @exec($cmd, $output, $return_code);
        
        $output_string  = implode("\n", $output);
        $error_output   = self::getMailOutput($output_string);
        
        if ($error_output) {
            Log::err('RA--EC-SEC mail() return this error output: "' . $error_output . '"');
        }
        
        if (intval($return_code) === 0) {
            return true;
        }
        return false;
    }
    
    public static function sendEmail()
    {
        $email      = Application::getEmail();
        $subject    = Locale::getMessage('ra.email.checker.subject');
        $text       = Locale::getMessage('ra.email.checker.text');
        
        $email_obj = EmailFactory::getEMail();
        $email_obj->setEmail($email);
        $email_obj->setSubject($subject);
        $email_obj->setText($text);
        echo self::MAIL_ERROR_MARKER;
        $result = $email_obj->send();
        if ($result) {
            Log::info('RA--EC-SE - sent email');
            
        }
        else {
            Log::err('RA--EC-SE - error sent email');
        }
        echo self::MAIL_ERROR_MARKER;
        return $result;
    }
    
    private static function getMailOutput($all_output)
    {
        if (preg_match('~' . self::MAIL_ERROR_MARKER . '(.*)' . self::MAIL_ERROR_MARKER . '~is', $all_output, $m)) {
            return trim($m[1]);
        }
        return '';
    }
    
    public static function sendSMTPEmailWithCheck()
    {
        $email      = Application::getEmail();
        $subject    = Locale::getMessage('ra.email.checker.subject');
        $text       = Locale::getMessage('ra.email.checker.text');
        
        $email_obj = EmailFactory::getEMail();
        $email_obj->setEmail($email);
        $email_obj->setSubject($subject);
        $email_obj->setText($text);
        $result = $email_obj->send();
        if ($result) {
            Log::info('RA--EC-SE - sent email');
        }
        else {
            Log::err('RA--EC-SE - error sent email');
        }
        return $result;
    }
}