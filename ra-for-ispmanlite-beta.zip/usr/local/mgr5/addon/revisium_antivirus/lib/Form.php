<?php

namespace RAISP;

class Form
{
    protected $options              = [];
    protected $have_request         = false;
    protected $validated_request    = true;
    
    const CONDITION_BOOL        = 'bool';
    const CONDITION_MORE_THEN_0 = 'more_then_0';
    
    public function __construct()
    {
        $this->parseParams();
    }
    
    public function getXML()
    {
        return $this->buildXML();
    }

    protected function parseParams()
    {
        if (!isset($_SERVER['PARAM_sok']) || ($_SERVER['PARAM_sok'] != 'ok')) {
            return;
        }
        
        $this->have_request = true;
        
        $has_license            = Application::hasLicense();
        $not_validated_fields   = [];
        
        foreach ($this->options as $option_name => &$option_params)
        {
            $type               = $option_params['type'];
            $need_license       = !isset($option_params['need_license'])        ? false : $option_params['need_license'];
            $values             = !isset($option_params['values'])              ? null  : $option_params['values'];
            $dependent_fields   = !isset($option_params['dependent_fields'])    ? []    : $option_params['dependent_fields'];
            $require            = !isset($option_params['require'])             ? false : $option_params['require'];
            if (!$has_license && $need_license) {
                continue;
            }
            $value = self::_getParam($option_name);
            if (!$this->allDependentFieldsIsOn($dependent_fields)) {
                continue;
            }
            if (!$this->validate($value, $type, $values, $require)) {
                $option_params['changed']   = false;
                $option_params['new_value'] = $value;
                $not_validated_fields[]     = $option_name;
                $this->validated_request    = false;
                if (isset($option_params['mess'])) {
                    Banners::setError(Locale::getMessage($option_params['mess']));
                }
                else {
                    Banners::setError(Locale::getMessage('ra.validator.all'));
                }
                continue;
            }
            $option_params['new_value'] = $value;
        }
        unset($option_params);
        
        if ($not_validated_fields) {
            return;
        }
        
        foreach ($this->options as $option_name => &$option_params)
        {
            if (!isset($option_params['new_value'])) {
                continue;
            }
            $app_method                 = 'set' . $option_params['app_method'];
            $option_params['changed']   = Application::$app_method($option_params['new_value']);
        }
        unset($option_params);
    }
    
    private function allDependentFieldsIsOn($fields)
    {
        if (empty($fields)) {
            return true;
        }
        foreach ($fields as $field_name => $condition)
        {
            if (!isset($this->options[$field_name])) {
                return false;
            }
            $value = isset($this->options[$field_name]['new_value']) ? $this->options[$field_name]['new_value'] : false;
            if ($condition == 'bool' && !$value) {
                return false;
            }
            elseif ($condition == 'more_then_0' && $value < 0) {
                return false;
            }
        }
        return true;
    }

    protected function buildXML()
    {
        $xml = '';
        foreach ($this->options as $option_name => $option_params) 
        {
            $app_method = 'get' . $option_params['app_method'];
            $type       = $option_params['type'];
            $value      = '';
            if (!$this->have_request || !isset($option_params['new_value'])) {
                $value = Application::$app_method($value);
            }
            else {
                $value = $option_params['new_value'];
            }
            if ($type == 'checkbox') {
                $value = $value ? 'on' : 'off';
            }
            
            $xml .= '<' . $option_name . '>' 
                    . htmlspecialchars($value)
                    .'</' . $option_name . '>';
        }
        return $xml;
    }
    
    private function validate(&$value, $type, $values = null, $require = false)
    {
        if ($type == 'checkbox') {
            $value = $value == 'off' ? false : true;
            return true;
        }
        elseif ($type == 'int') {
            $value = trim($value);
            if ($value === '') {
                return false;
            }
            if (preg_match('~[^\-0-9]~', $value)) {
                return false;
            }
            $value = intval($value);
            if (!is_null($values) && !in_array($value, $values)) {
                return false;
            }
            return true;
        }
        elseif ($type == 'email') {
            $value = trim($value);
            if (empty($value)) {
                return false;
            }
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            }
            return true;
        }
        elseif ($type == 'host') {
            $value = trim($value);
            if (!filter_var($value, FILTER_VALIDATE_DOMAIN) && !filter_var($value, FILTER_VALIDATE_IP)) {
                return false;
            }
            return true;
        }
        elseif ($type == 'string') {
            if ($require && empty($value)) {
                return false;
            }
            return true;
        }
        return false;
    }
    
    private static function _getParam($name, $default = 0)
    {
        $key = 'PARAM_' . $name;
        if (!isset($_SERVER[$key])) {
            return $default;
        }
        return $_SERVER[$key];
    }
    
    private static function _checkedParams($name)
    {
        return self::_getParam($name) == 'off' ? false : true;
    }
}