<?php
namespace RAISP;

class Client extends ScannableFolder
{
    private static $users_types = [];

    private $path           = '';
    private $ra_domains     = [];
    
    public function __construct($name, $path) 
    {
        $this->name         = $name;
        $this->path         = $path;
        $this->folder_info  = new \scaforeSDK\FolderInfo($path);
    }
    
    public function getOwner()
    {
        return $this->name;
    }
    
    public function getPath()
    {
        return $this->path;
    }
    
    public function getPathForCheck()
    {
        return $this->getPath();
    }
    
    public function getClientForCheck()
    {
        return $this->getName();
    }

    public function addDomainToList(Domain $ra_domain)
    {
        $this->ra_domains[] = $ra_domain;
    }
    
    public function getDomains()
    {
        return $this->ra_domains;
    }
    
    public static function getClientByName($name)
    {
        $ra_clients = self::getAllClients();
        foreach ($ra_clients as $ra_client)
        {
            if ($ra_client->getName() == $name) {
                return $ra_client;
            }
        }
        Log::err('RA--CL-GC ' . $name . ' Client not found');
        return false;
    }

    // =====================================================
    
    public static function getAllClients($all_clients = false)
    {
        $all_domains    = Domain::getAllDomain($all_clients);
        $clients        = [];
        foreach ($all_domains as $ra_domain)
        {
            $client_name = $ra_domain->getOwner();
            if (!isset($clients[$client_name])) {
                $client_path            = preg_replace('~/[^/]+/[^/]+$~', '', $ra_domain->getDocRoot());// /[^/]+
                $clients[$client_name]  = new Client($client_name, $client_path);
            }
            $clients[$client_name]->addDomainToList($ra_domain);
        }
        return array_values($clients);
    }
    
    public static function isAdmin($username)
    {
        if (isset(self::$users_types[$username])) {
            return self::$users_types[$username];
        }
        self::$users_types[$username] = false;
        exec('/usr/local/mgr5/sbin/mgrctl -m ispmgr admin', $result);
        $str = implode("\n", $result);
        if (!preg_match_all('~name=([^\s]+)~smi', $str, $matches, PREG_SET_ORDER)) {
            return false;
        }
        foreach ($matches as $m)
        {
            if ($username == $m[1]) {
                self::$users_types[$username] = true;
                return true;
            }
        }
        return false;
    }
    
    public static function getCurrentUsername()
    {
        return isset($_SERVER['AUTH_USER']) ? trim($_SERVER['AUTH_USER']) : '';
    }    
    
    public static function currentUserIsAdmin()
    {
        if (self::isAdmin(self::getCurrentUsername())) {
            return true;
        }
        return false;
    }
    
}