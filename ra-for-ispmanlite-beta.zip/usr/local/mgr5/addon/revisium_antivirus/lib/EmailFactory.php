<?php

namespace RAISP;

class EmailFactory
{
    public static function getEMail()
    {
        if (!\RAISP\Application::getEmailNotif()) {
            return false;
        }
        if (!\RAISP\Application::getUseSMTP()) {
            return new \framework\Email\EmailPHPMail();
        }
        $smtp_server    = \RAISP\Application::getSMTPServer();
        $smtp_user      = \RAISP\Application::getSMTPUser();
        $smtp_password  = \RAISP\Application::getSMTPPassword();
        $smtp_port      = \RAISP\Application::getSMTPPort();
        $smtp_use_ssl   = \RAISP\Application::getSMTPUseSSL();
        
        if (empty($smtp_server)) {
            return false;
        }
        $email = new \framework\Email\EmailSMTP();
        $email->setParams($smtp_server, $smtp_user, $smtp_password, $smtp_port, $smtp_use_ssl);
        return $email;
    }
}