<?php

namespace RAISP;

class Application
{
    const MODE_BY_DOMAIN    = 'by_domain';
    const MODE_BY_USER      = 'by_user';
    
    private static $version = '1.5.1';

    private static $def_quick_scan          = true;
    private static $def_skip_media          = true;
    private static $def_optimize_by_speed   = true;
    private static $def_num_of_threads      = 1;
    private static $def_period              = -1;
    private static $def_start_at            = 1;
    private static $def_max_memory          = 256;
    private static $def_keep_backup         = 14;
    private static $def_trim_file           = true;
    private static $def_queue_timout        = 24 * 60 * 60;
    private static $def_working_timout      = 2 * 60 * 60;
    private static $def_executor_timeout    = 2 * 60 * 60 + 10;
    private static $def_scan_timeout        = 60 * 60;
    private static $def_cure_timeout        = 60 * 60;
    private static $def_email_notif         = false;
    private static $def_email               = '';
    private static $def_use_smtp            = false;
    private static $def_smtp_server         = '';
    private static $def_smtp_user           = '';
    private static $def_smtp_password       = '';
    private static $def_smtp_port           = '';
    private static $def_smtp_use_ssl        = false;
    private static $def_can_use_stdin       = true;
    private static $def_check_blacklisted   = true;
    private static $def_app_mode            = self::MODE_BY_DOMAIN;
    private static $def_ttl_sort            = 365 * 24 * 60 * 60;
    private static $def_log_level           = Log::INFO;
    private static $have_license            = null;
    private static $lang                    = null;
    private static $def_lang                = Locale::LANG_EN;
    private static $stdin                   = null;
    
    // ==========================================================

    public static function recacheKeyValueStorage()
    {
        KeyValueStorage::recache();
    }


    public static function getQuickScan()
    {
        return KeyValueStorage::get('quick_scan', self::$def_quick_scan);
    }

    public static function setQuickScan($value)
    {
        return KeyValueStorage::set('quick_scan', $value);
    }

    public static function getSkipMedia()
    {
        return KeyValueStorage::get('skip_media', self::$def_skip_media);
    }

    public static function setSkipMedia($value)
    {
        return KeyValueStorage::set('skip_media', $value);
    }

    public static function getOptimizeBySpeed()
    {
        return KeyValueStorage::get('optimize_by_speed', self::$def_optimize_by_speed);
    }

    public static function setOptimizeBySpeed($value)
    {
        return KeyValueStorage::set('optimize_by_speed', $value);
    }
    
    public static function getNumOfThreads()
    {
        return intval(KeyValueStorage::get('num_of_threads', self::$def_num_of_threads));
    }

    public static function setNumOfThreads($value)
    {
        return KeyValueStorage::set('num_of_threads', intval($value));
    }

    public static function getPeriod()
    {
        $scan_period = intval(KeyValueStorage::get('period', self::$def_period));
        if ($scan_period == -1) {
            return $scan_period;
        }
        if (!self::hasLicense()) {
            return -1;
        }
        return $scan_period;
    }

    public static function setPeriod($value)
    {
        return KeyValueStorage::set('period', intval($value));
    }
    
    public static function getStartAt()
    {
        return intval(KeyValueStorage::get('start_at', self::$def_start_at));
    }

    public static function setStartAt($value)
    {
        return KeyValueStorage::set('start_at', intval($value));
    }
    
    public static function getMaxMemory()
    {
        return intval(KeyValueStorage::get('max_memory', self::$def_max_memory));
    }

    public static function setMaxMemory($value)
    {
        return KeyValueStorage::set('max_memory', intval($value));
    }

    public static function getKeepBackup()
    {
        return intval(KeyValueStorage::get('keep_backup', self::$def_keep_backup));
    }

    public static function setKeepBackup($value)
    {
        return KeyValueStorage::set('keep_backup', intval($value));
    }
    
    public static function getTrimFile()
    {
        return KeyValueStorage::get('trim_file', self::$def_trim_file);
    }

    public static function setTrimFile($value)
    {
        return KeyValueStorage::set('trim_file', $value);
    }
    
    public static function getEmailNotif()
    {
        return KeyValueStorage::get('email_notif', self::$def_email_notif);
    }
    
    public static function setEmailNotif($value)
    {
        return KeyValueStorage::set('email_notif', $value);
    }
    
    public static function getEmail()
    {
        return KeyValueStorage::get('email', self::$def_email);
    }
    
    public static function setEmail($value)
    {
        return KeyValueStorage::set('email', $value);
    }
    
    public static function getUseSMTP()
    {
        return KeyValueStorage::get('use_smtp', self::$def_use_smtp);
    }
    
    public static function setUseSMTP($value)
    {
        return KeyValueStorage::set('use_smtp', $value);
    }
    
    public static function getSMTPServer()
    {
        $result = KeyValueStorage::get('smtp_server', null);
        if (!is_null($result)) {
            return $result;
        }
        return SMTPEmailParams::getSMTPServer();
    }
    
    public static function setSMTPServer($value)
    {
        return KeyValueStorage::set('smtp_server', $value);
    }
    
    public static function getSMTPUser()
    {
        $result = KeyValueStorage::get('smtp_user', null);
        if (!is_null($result)) {
            return $result;
        }
        return SMTPEmailParams::getSMTPUser();
    }
    
    public static function setSMTPUser($value)
    {
        return KeyValueStorage::set('smtp_user', $value);
    }
    
    public static function getSMTPPassword()
    {
        $result = KeyValueStorage::get('smtp_password', null);
        if (!is_null($result)) {
            return $result;
        }
        return SMTPEmailParams::getSMTPPassword();
    }
    
    public static function setSMTPPassword($value)
    {
        return KeyValueStorage::set('smtp_password', $value);
    }
    
    
    public static function getSMTPUseSSL()
    {
        return KeyValueStorage::get('smtp_use_ssl', self::$def_smtp_use_ssl);
    }

    public static function setSMTPUseSSL($value)
    {
        return KeyValueStorage::set('smtp_use_ssl', $value);
    }
    
    public static function getSMTPPort()
    {
        $result = KeyValueStorage::get('smtp_port', null);
        if (!is_null($result)) {
            return $result;
        }
        return SMTPEmailParams::getSMTPPort();
    }

    public static function setSMTPPort($value)
    {
        return KeyValueStorage::set('smtp_port', $value);
    }

    public static function getQueueTimeout()
    {
        return self::$def_queue_timout;
    }
    
    public static function getWorkingTimeout()
    {
        return self::$def_working_timout;
    }
    
    public static function getNeedSendNotification()
    {
        return (bool)KeyValueStorage::get('need_send_notification', null);
    }

    public static function setNeedSendNotification($value)
    {
        KeyValueStorage::set('need_send_notification', $value);
    }
    
    public static function canUseSTDIN()
    {
        return self::$def_can_use_stdin;
    }
    
    public static function offSTDIN()
    {
        self::$def_can_use_stdin = false;
    }
    public static function setNeedCheckSMTP()
    {
        KeyValueStorage::set('need_check_smtp', true);
    }
    
    public static function needCheckSMTP()
    {
        $result = (bool)KeyValueStorage::get('need_check_smtp', false);
        if ($result) {
            KeyValueStorage::set('need_check_smtp', false);
        }
        return $result;
    }
    
    public static function setScriptLang()
    {
        KeyValueStorage::set('script_lang', self::getLang());
    }
    
    public static function getScriptLang()
    {
        return KeyValueStorage::get('script_lang', self::$def_lang);
    }
    
    public static function setCheckBlacklisted($check)
    {
        return KeyValueStorage::set('check_blacklisted', $check);
    }
    
    public static function getCheckBlacklisted()
    {
        return (bool)KeyValueStorage::get('check_blacklisted', self::$def_check_blacklisted);
    }
    
    public static function getVersion()
    {
        return self::$version;
    }
    
    public static function setAppMode($mode)
    {
        KeyValueStorage::set('app_mode', $mode);
    }
    
    public static function getAppMode()
    {
        return KeyValueStorage::get('app_mode', self::$def_app_mode);
    }
    
    public static function getLogLevel()
    {
        return KeyValueStorage::get('log_level', self::$def_log_level);
    }
    
    public static function setLogLevel($log_level)
    {
        KeyValueStorage::set('log_level', $log_level);
    }

    public static function getTTLSort()
    {
        return self::$def_ttl_sort;
    }
    
    public static function getScanTimeout()
    {
        return self::$def_scan_timeout;
    }
    
    public static function getCureTimeout()
    {
        return self::$def_cure_timeout;
    }

    public static function getExecutorTimeout()
    {
        return self::$def_executor_timeout;
    }

    // ==========================================================
    
    public static function setLang($lang)
    {
        $langs = [Locale::LANG_EN, Locale::LANG_RU];
        if (!in_array($lang, $langs)) {
            return;
        }
        self::$lang = $lang;
    }

    public static function getLang()
    {
        if (is_null(static::$lang)) {
            self::$lang = '';
            self::determineLang();
        }
        if (empty(self::$lang)) {
            return self::$def_lang;
        }
        return self::$lang;
    }
    
    public static function getDefLang()
    {
        return self::$def_lang;
    }
    
    public static function langIsRU()
    {
        if (self::getLang() == Locale::LANG_RU) {
            return true;
        }
        return false;
    }

    public static function getPHPHandler()
    {
        return RA_PHP_HANDLER;
    }

    public static function getPHPIniPath()
    {
        return RA_PHP_INI;
    }

    private static function determineLang()
    {
        $xml    = self::getStdin();
        $lang   = '';
        if (!empty($xml) && preg_match('~lang\s*=\s*"([^"]*)"~', $xml, $m)) {
            
            $lang = trim($m[1]);
        }
        if ($lang == Locale::LANG_EN) {
            self::setLang(Locale::LANG_EN);
        }
        elseif ($lang == Locale::LANG_RU) {
            self::setLang(Locale::LANG_RU);
        }
        else {
            self::setLang(Application::getScriptLang());
        }
    }
    
    public static function getStdin()
    {
        if (!self::canUseSTDIN()) {
            return '';
        }
        if (!is_null(self::$stdin)) {
            return self::$stdin;
        }
        self::$stdin = isset($_SERVER['RA_STDIN']) ? $_SERVER['RA_STDIN'] : '';
        return self::$stdin;
    }

    public static function hasLicense() 
    {
        
        // file_put_contents('/tmp/aaa.txt', var_export($_SERVER, true));
        //       return true; // [HACK FOR TEST]
 
        // in memory cache
        if (!is_null(self::$have_license)) {
            return self::$have_license;
        }

        $license    = 'Module: RevisiumAntivirus';
        $unq_string = @filesize("/proc/cpuinfo");
        $cache_file = "/tmp/rlcache_" . md5(__FILE__ . $unq_string);
        $cache_file_tmp = "/tmp/t_rlcache_" . md5(__FILE__ . $unq_string);
        $cache_time = 10;

        // invalid by default
        $valid = false;

        if (@$_SERVER['PARAM_func'] == 'revisium_antivirus_func') {
           @unlink($cache_file);
        }

        // check if the license file exists and is up to date?
        if (@file_exists($cache_file)) {
            // file si up to date
            if (time() - @filemtime($cache_file) < $cache_time) {
                $valid = true;  
            } else {
                // expired, remove it
                @unlink($cache_file);
            }
        }
        

        // if license is not up to date, obtain it from licctl
        if (!$valid) {
            @exec("/usr/local/mgr5/sbin/licctl info /usr/local/mgr5/etc/ispmgr.lic > " . $cache_file_tmp, $result, $code);
            // encrypt file
            @file_put_contents($cache_file, 
                  str_rot13(base64_encode(str_rot13(strrev(@base64_encode(@file_get_contents($cache_file_tmp)))))), LOCK_EX);
            @unlink($cache_file_tmp);
        }

        $str = @base64_decode(strrev(str_rot13(@base64_decode(str_rot13(@file_get_contents($cache_file))))));
        
        if (@strpos($str, $license) !== false) {
            self::$have_license = true;
        } else {
            self::$have_license = false; 
        }

        return self::$have_license;
    }
    
}