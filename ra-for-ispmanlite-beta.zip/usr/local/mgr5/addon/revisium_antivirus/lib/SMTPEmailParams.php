<?php

namespace RAISP;

class SMTPEmailParams
{
    const SMTP_SERVER   = 'smtpserver';
    const SMTP_USER     = 'smtpuser';
    const SMTP_PASSWORD = 'smtppassword';
    const SMTP_PORT     = 'smtpport';
    
    private static $smtp_settings = null;
    
    public static function getSMTPServer()
    {
        if (is_null(self::$smtp_settings)) {
            self::loadSMTPSettings();
        }
        return self::$smtp_settings[self::SMTP_SERVER];
    }

    public static function getSMTPUser()
    {
        if (is_null(self::$smtp_settings)) {
            self::loadSMTPSettings();
        }
        return self::$smtp_settings[self::SMTP_USER];
    }
    
    public static function getSMTPPassword()
    {
        if (is_null(self::$smtp_settings)) {
            self::loadSMTPSettings();
        }
        return self::$smtp_settings[self::SMTP_PASSWORD];
    }
    
    public static function getSMTPPort()
    {
        if (is_null(self::$smtp_settings)) {
            self::loadSMTPSettings();
        }
        return self::$smtp_settings[self::SMTP_PORT];
    }

    //==============================================================
    
    private static function loadSMTPSettings()
    {
        $result = [
            self::SMTP_SERVER   => '',
            self::SMTP_USER     => '',
            self::SMTP_PASSWORD => '',
            self::SMTP_PORT     => '',
        ];
        
        exec('/usr/local/mgr5/sbin/mgrctl -m ispmgr emailnotify', $out);
        
        foreach ($out as $line) 
        {
            if (empty($line)) {
                continue;
            }
            $params = explode('=', $line, 2);
            $key    = $params[0];
            $value  = $params[1];
            if (isset($result[$key])) {
                $result[$key] = $value;
            }
        }
        self::$smtp_settings = $result;
    }

}