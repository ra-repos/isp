<?php

namespace RAISP;

class Banners
{
    const TYPE_ERROR        = 1;
    const TYPE_WARNING      = 2;
    const TYPE_NOTIFICATION = 3;
    
    private static $banners = [];
    
    
    public static function setError($msg)
    {
        self::setBanner(self::TYPE_ERROR, $msg);
    }

    public static function setWarning($msg)
    {
        self::setBanner(self::TYPE_WARNING, $msg);
    }

    public static function setNotification($msg)
    {
        self::setBanner(self::TYPE_NOTIFICATION, $msg);
    }
    
    public static function renderBanners()
    {
        if (!self::$banners) {
            return '';
        }
        $result = '';
        foreach (self::$banners as $banner)
        {
            $template = new Template('ra_banner');
            $template->setParams([
                'MSG'     => $banner['msg'],
                'TYPE'    => $banner['type'],
            ]);
            $result .= $template->build();                        
        }
        return $result;
    }

    // ==================================================

    private static function setBanner($type, $msg)
    {
        self::$banners[sha1($msg)] = [
            'type'  => $type,
            'msg'   => $msg,
        ];
    }
}