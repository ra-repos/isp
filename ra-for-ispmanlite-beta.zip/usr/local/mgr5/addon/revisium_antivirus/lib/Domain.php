<?php

namespace RAISP;

class Domain extends ScannableFolder
{
    private $owner      = '';
    private $doc_root   = '';
    private $ips        = [];
    
    public function __construct($name, $owner, $doc_root, $ips) 
    {
        $this->name         = $name;
        $this->owner        = $owner;
        $this->doc_root     = $doc_root;
        $this->ips          = $ips;
        $this->folder_info  = new \scaforeSDK\FolderInfo($doc_root);
    }
    
    public function getOwner()
    {
        return $this->owner;
    }
    
    public function getNameInPunyCode()
    {
        return idn_to_ascii($this->name);
    }
    
    public function getDocRoot()
    {
        return $this->doc_root;
    }
    
    public function getPathForCheck()
    {
        return $this->getDocRoot();
    }
    
    public function getClientForCheck()
    {
        return $this->getOwner();
    }
    
    public function getIPs()
    {
        return $this->ips;
    }
    
    // ==============================================================
    
    public static function getAllDomain($all_domains = false)
    {
        $current_user = Client::getCurrentUsername();
        if (Client::isAdmin($current_user)) {
            $all_domains = true; 
        }
        $domains_params = \RAISP\ISP::runCommand('/usr/local/mgr5/sbin/mgrctl -m ispmgr webdomain');
        $domains        = [];
        foreach ($domains_params as $domain_params)
        {
            $owner      = $domain_params['owner'];
            if (!$all_domains && ($owner != $current_user)) {
                continue;
            }
            $name       = $domain_params['name'];
            $docroot    = $domain_params['docroot'];
            $ips        = array_map('trim', explode(',', $domain_params['ipaddr']));
            $domains[]  = new Domain($name, $owner, $docroot, $ips);
        }
        return $domains;
    }
    
    public static function getDomainByDomainName($name)
    {
        $domains = self::getAllDomain();
        foreach ($domains as $domain)
        {
            if ($domain->getName() == $name) {
                return $domain;
            }
        }
        Log::err('RA--DM-GD ' . $name . ' domain not found');
        return false;
    }
}