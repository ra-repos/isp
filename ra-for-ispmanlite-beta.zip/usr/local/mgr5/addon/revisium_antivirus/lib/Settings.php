<?php

namespace RAISP;

class Settings extends Form
{
    protected $options    = [
        'quick_scan'        => [
            'type'              => 'checkbox',
            'app_method'        => 'QuickScan',
        ],
        
        'skip_media'        => [
            'type'              => 'checkbox',
            'app_method'        => 'SkipMedia',
        ],
        
        'optimize_by_speed' => [
            'type'              => 'checkbox',
            'app_method'        => 'OptimizeBySpeed',
        ],
        
        'trim_file'         => [
            'type'              => 'checkbox',
            'need_license'      => true,
            'app_method'        => 'TrimFile',
            'mess'              => 'ra.validator.trim_file',
        ],
        
        'check_blacklisted' => [
            'type'              => 'checkbox',
            'app_method'        => 'CheckBlacklisted',
        ],
        
        'period'            => [
            'type'              => 'int',
            'app_method'        => 'Period',
            'values'            => [-1, 1, 7, 30],
            'mess'              => 'ra.validator.period',
        ],
        
        'num_of_threads'    => [
            'type'              => 'int',
            'app_method'        => 'NumOfThreads',
            'values'            => [1, 2, 4],
            'scafore_reload'    => true,
            'mess'              => 'ra.validator.num_of_threads',
        ],
        
        'max_memory'        => [
            'type'              => 'int',
            'app_method'        => 'MaxMemory',
            'values'            => [256, 384, 512, 1024],
            'mess'              => 'ra.validator.max_memory',
        ],
        
        'keep_backup'       => [
            'type'              => 'int',
            'need_license'      => true,
            'app_method'        => 'KeepBackup',
            'values'            => [7, 14, 30],
            'scafore_reload'    => true,
            'mess'              => 'ra.validator.keep_backup',
        ],
        
        'start_at'          => [
            'type'              => 'int',
            'need_license'      => true,
            'values'            => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
            'app_method'        => 'StartAt',
            'dependent_fields'  => ['period' => self::CONDITION_MORE_THEN_0],
            'mess'              => 'ra.validator.start_at',
        ],
        
        'email_notif'       => [
            'type'              => 'checkbox',
            'need_license'      => true,
            'app_method'        => 'EmailNotif',
        ],
        
        'email'             => [
            'type'              => 'email',
            'need_license'      => true,
            'app_method'        => 'Email',
            'dependent_fields'  => ['email_notif' => self::CONDITION_BOOL, 'period' => self::CONDITION_MORE_THEN_0],
            'mess'              => 'ra.validator.email',
        ],
        
        'use_smtp'          => [
            'type'              => 'checkbox',
            'need_license'      => true,
            'dependent_fields'  => ['email_notif' => self::CONDITION_BOOL, 'period' => self::CONDITION_MORE_THEN_0],
            'app_method'        => 'UseSMTP',
        ],
        
        'smtp_server'       => [
            'type'              => 'host',
            'need_license'      => true,
            'require'           => true,
            'app_method'        => 'SMTPServer',
            'dependent_fields'  => ['use_smtp' => self::CONDITION_BOOL, 'email_notif' => self::CONDITION_BOOL, 'period' => self::CONDITION_MORE_THEN_0],
            'mess'              => 'ra.validator.smtp_server',
        ],
        
        'smtp_user'         => [
            'type'              => 'string',
            'need_license'      => true,
            'require'           => true,
            'dependent_fields'  => ['use_smtp' => self::CONDITION_BOOL, 'email_notif' => self::CONDITION_BOOL, 'period' => self::CONDITION_MORE_THEN_0],
            'app_method'        => 'SMTPUser',
            'mess'              => 'ra.validator.smtp_user',
        ],
        
        'smtp_password'     => [
            'type'              => 'string',
            'need_license'      => true,
            'require'           => true,
            'dependent_fields'  => ['use_smtp' => self::CONDITION_BOOL, 'email_notif' => self::CONDITION_BOOL, 'period' => self::CONDITION_MORE_THEN_0],
            'app_method'        => 'SMTPPassword',
            'mess'              => 'ra.validator.smtp_password',
        ],
        
        'smtp_port'         => [
            'type'              => 'int',
            'need_license'      => true,
            'require'           => true,
            'app_method'        => 'SMTPPort',
            'dependent_fields'  => ['use_smtp' => self::CONDITION_BOOL, 'email_notif' => self::CONDITION_BOOL, 'period' => self::CONDITION_MORE_THEN_0],
            'mess'              => 'ra.validator.smtp_port',
        ],
        
        'smtp_use_ssl'      => [
            'type'              => 'checkbox',
            'need_license'      => false,
            'dependent_fields'  => ['use_smtp' => self::CONDITION_BOOL, 'email_notif' => self::CONDITION_BOOL, 'period' => self::CONDITION_MORE_THEN_0],
            'app_method'        => 'SMTPUseSSL',
        ],
        
    ];
    
    public function __construct() 
    {
        parent::__construct();
        if ($this->have_request && $this->validated_request) {
            Banners::setNotification(Locale::getMessage('ra.saved'));
            $this->checkEmailIfNeed();
        }
        Application::setScriptLang();
    }
    
    private function checkEmailIfNeed()
    {
        if (!Application::hasLicense()) {
            return;
        }
        
        if (Application::getPeriod() == -1) {
            return;
        }
        
        if (!Application::getEmailNotif()) {
            return;
        }
        
        if (!Application::getEmail()) {
            return;
        }
        
        $this->checkPHPMailIFNeed();
        $this->checkSMTPIFNeed();
    }
    
    private function checkPHPMailIFNeed()
    {
        if (Application::getUseSMTP()) {
            return;
        }
        
        $changed_email_notif    = $this->options['email_notif']['changed'];
        $changed_email          = $this->options['email']['changed'];
        $changed_smtp_use       = $this->options['use_smtp']['changed'];
        
        if (!$changed_email_notif && !$changed_email && !$changed_smtp_use) {
            return;
        }
        
        if (EmailChecker::sendEmailWithCheck()) {
            Banners::setNotification(Locale::getMessage('ra.settings.test_phpmail_sent'));
        }
        else {
            $this->options['use_smtp']['new_value'] = true;
            $this->options['use_smtp']['changed']   = true;
            Application::setUseSMTP(true);
            Application::setNeedCheckSMTP();
            Banners::setError(Locale::getMessage('ra.settings.test_phpmail_not_sent'));
        }
    }
    
    private function checkSMTPIfNeed()
    {
        if (!Application::getUseSMTP()) {
            return;
        }
        
        $changed_use_smtp       = $this->options['use_smtp']['changed'];
        $smtp_params_changed    = $this->options['smtp_server']['changed'] 
                || $this->options['smtp_user']['changed'] 
                || $this->options['smtp_password']['changed'] 
                || $this->options['smtp_port']['changed'] 
                || $this->options['smtp_use_ssl']['changed'];
        
        $have_smtp_params = Application::getSMTPServer() 
                    && Application::getSMTPUser() 
                    && Application::getSMTPPassword() 
                    && Application::getSMTPPort();
        
        if ($smtp_params_changed && !$have_smtp_params) {
            Banners::setError(Locale::getMessage('ra.settings.worng_smtp_settings'));
        }
        if ($have_smtp_params && (Application::needCheckSMTP() || $changed_use_smtp || $smtp_params_changed)) {
            if (EmailChecker::sendSMTPEmailWithCheck()) {
                Banners::setNotification(Locale::getMessage('ra.settings.test_smtp_sent'));
            }
            else {
                Banners::setError(Locale::getMessage('ra.settings.test_smtp_not_sent'));
            }
        }
    }

    protected function buildXML()
    {
        return '<license>' . (Application::hasLicense() ? '1' : '') . '</license>' . parent::buildXML();
    }
    
}