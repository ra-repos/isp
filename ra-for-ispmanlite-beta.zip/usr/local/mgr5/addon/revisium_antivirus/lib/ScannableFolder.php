<?php

namespace RAISP;

abstract class ScannableFolder
{
    protected $name         = '';
    protected $folder_info  = null;

    abstract public function getOwner();
    
    public function getName()
    {
        return $this->name;
    }

    public function getFolderInfo()
    {
        return $this->folder_info;
    }
}
