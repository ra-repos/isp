<?php

namespace RAISP;

class Locale
{
    const LANG_EN = 'en';
    const LANG_RU = 'ru';
    
    private static $lang = null;
    
    public static function getMessage($key, $params = [])
    {
        $value      = '';
        $used_lang  = '';
        $array_name = self::getMessageVarName(false, $used_lang);
        if (isset($GLOBALS[$array_name][$key])) {
            $value = $GLOBALS[$array_name][$key];
        }
        else {
            $array_name_def = self::getMessageVarName(true, $used_lang);
            if ($array_name !== $array_name_def && isset($GLOBALS[$array_name_def][$key])) {
                $value = $GLOBALS[$array_name_def][$key];
            }
        }
        if (!empty($value) && strpos($value, '%%') !== false) {
            $value = self::replace($value, $params);
        }
        return self::replaceNumeralEnds($value, $used_lang);
    }
    
    public static function checkKey($key)
    {
        $array_name = self::getMessageVarName(false);
        if (isset($GLOBALS[$array_name][$key])) {
            return true;
        }
        $array_name_def = self::getMessageVarName(true);
        if ($array_name !== $array_name_def && isset($GLOBALS[$array_name_def][$key])) {
            return true;
        }
        return false;
    }

    // ===========================================
    
    private static function replace($value, $params)
    {
        return preg_replace_callback('~%%([^%\s]+)%%~', function ($matchs) use ($params) {
            return isset($params[$matchs[1]]) ? $params[$matchs[1]] : '';
        }, $value);
    }
    
    private static function replaceNumeralEnds($text, $used_lang)
    {
        if ($used_lang === self::LANG_RU) {
            $text = preg_replace_callback('~\{\{(\d+):([^,]*),([^,]*),([^,]*)\}\}~', 'self::ruReplace', $text);
        }
        else {
            $text = preg_replace_callback('~\{\{(\d+):([^,]*),([^,]*)\}\}~', 'self::enReplace', $text);
        }
        $text_result = preg_replace('~\{\{[^\]]*\}\}~', '', $text);
        if ($text_result != $text) {
            Log::err('RA--LC-RNE - wrong_template:' . $text);
        }
        return $text_result;
    }

    private static function getMessageVarName($default_lang, &$used_lang = '')
    {
        $prefix     = 'ra_messages_';
        $used_lang  = '';
        if ($default_lang) {
            $used_lang = Application::getDefLang();
            return $prefix . $used_lang;
        }
        if (is_null(self::$lang)) {
            self::$lang = Application::getLang();
        }
        $used_lang = self::$lang;
        return $prefix . $used_lang;
    }
    
    private static function ruReplace($matches)
    {
        $cnt    = $matches[1];
        $tr1    = $matches[2];
        $tr2    = $matches[3];
        $tr3    = $matches[4];
        
        $o100   = $cnt % 100;
        $o10    = $cnt % 10;
        
        if ($o100 >= 5 && $o100 <= 20) {
            return $tr1;
        }
        elseif ($o10 == 0 || $o10 >= 5 && $o10 <= 9) {
            return $tr1;
        }
        elseif ($o10 === 1) {
            return $tr2;
        }
        elseif ($o10 >= 2 && $o10 <= 4) {
            return $tr3;
        }
        return '';
    }

    private static function enReplace($matches)
    {
        $cnt    = $matches[1];
        $tr1    = $matches[2];
        $tr2    = $matches[3];
        
        if ($cnt == 1) {
            return $tr1;
        }
        return $tr2;
    }
    
}
