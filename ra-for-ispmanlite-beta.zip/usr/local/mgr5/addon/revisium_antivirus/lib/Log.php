<?php

namespace RAISP;

class Log extends \framework\Log
{
}