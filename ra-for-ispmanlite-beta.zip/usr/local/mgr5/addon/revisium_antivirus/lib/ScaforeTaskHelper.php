<?php

namespace RAISP;

class ScaforeTaskHelper
{
    private static $result_folder = '/tmp';
    
    public static function setResultFolder($folder)
    {
        self::$result_folder = $folder;
    }

    public static function startScan(ScannableFolder $folder)
    {
        $folder_info = $folder->getFolderInfo();
        $folder_info->initInfo();
        
        $folder_path        = $folder_info->getFolder();
    
        $task_id            = \scaforeSDK\Task\Task::getTaskId($folder_path);
        $scan_task_params   = new \scaforeSDK\Task\ScanTaskParams();
        $scan_task_params->setFolder($folder_path);
        $scan_task_params->setTaskWorkDir(self::getTaskWorkDir($task_id));
        $scan_task_params->setType('paranoid');
        $scan_task_params->setAntivirus('hoster');
        $scan_task_params->setUsername($folder->getOwner());
        $scan_task_params->setMaxMemory(Application::getMaxMemory());
        $scan_task_params->setOptimize(Application::getOptimizeBySpeed() ? 'speed' : '');
        $scan_task_params->setMode(Application::getSkipMedia() ? 'no_media' : 'full');
        if (Application::getQuickScan()) {
            $scan_task_params->setMode('quick');
        }
        if ($folder instanceof Domain) {
            $scan_task_params->setCheckBlacklisted((int)Application::getCheckBlacklisted());
            $scan_task_params->setHasLicense((int)Application::hasLicense());
            $scan_task_params->setClientVersion(Application::getVersion());
            $scan_task_params->setHost($folder->getNameInPunyCode());
            $scan_task_params->setIPs($folder->getIPs());
        }
        $task = new \scaforeSDK\Task\ScanTask($task_id, $scan_task_params);
        if (\scaforeSDK\Task\TaskManager::addTask($task, \framework\TaskManager::QUEUE_TYPE_NORMAL)) {
            $folder_info->setCurrentWorkingTask($task::getTaskName());
            $folder_info->setState(\framework\Task::STATE_QUEUED);
            return true;
        }
        Log::warn('RA--STH-SS ' . $folder_path . ' Cannot add task to queue');
        return false;
    }
    
    public static function startCureForAllFiles(ScannableFolder $folder)
    {
        $folder_info = $folder->getFolderInfo();
        $folder_info->initInfo();
        
        $folder_path        = $folder_info->getFolder();
        $task_id            = \scaforeSDK\Task\Task::getTaskId($folder_path);
        
        $cure_task_params = new \scaforeSDK\Task\CureTaskParams();
        $cure_task_params->setFolder($folder_path);
        $cure_task_params->setTaskWorkDir(self::getTaskWorkDir($task_id));
        $cure_task_params->setTrim(\RAISP\Application::getTrimFile());
        $cure_task_params->setUsername($folder->getOwner());
        $cure_task_params->setCureAllFiles();
        $task = new \scaforeSDK\Task\CureTask($task_id, $cure_task_params);
        if (\scaforeSDK\Task\TaskManager::addTask($task, \framework\TaskManager::QUEUE_TYPE_NORMAL)) {
            $folder_info->setCurrentWorkingTask($task::getTaskName());
            $folder_info->setState(\framework\Task::STATE_QUEUED);
            return true;
        }
        Log::warn('RA--STH-SCAF ' . $folder_path . ' Cannot add task to queue');
        return false;
    }
    
    public static function startSyncCureForFile(ScannableFolder $folder, $sub_filepath)
    {
        $folder_info = $folder->getFolderInfo();
        $folder_info->initInfo();
        
        $folder_path        = $folder_info->getFolder();
        $task_id            = \scaforeSDK\Task\Task::getTaskId($folder_path);
        
        $cure_task_params = new \scaforeSDK\Task\CureTaskParams();
        $cure_task_params->setFolder($folder_path);
        $cure_task_params->setTaskWorkDir(self::getTaskWorkDir($task_id));
        $cure_task_params->setTrim(\RAISP\Application::getTrimFile());
        $cure_task_params->setUsername($folder->getOwner());
        $cure_task_params->setInfectedFiles([$sub_filepath]);
        $task = new \scaforeSDK\Task\CureTask($task_id, $cure_task_params);
        if (\scaforeSDK\Task\TaskManager::addTask($task, \framework\TaskManager::QUEUE_TYPE_NON_WAIT)) {
            $folder_info->setCurrentWorkingTask($task::getTaskName());
            $folder_info->setState(\framework\Task::STATE_QUEUED);
            return self::waitSyncTask($task, 10);
        }
        Log::warn('RA--STH-SSCF ' . $folder_path . ' Cannot add task to queue');
        return false;
    }
    
    public static function startSyncUndoForFile(ScannableFolder $folder, $sub_filepath)
    {
        $folder_info = $folder->getFolderInfo();
        $folder_info->initInfo();
        
        $folder_path        = $folder_info->getFolder();
        $task_id            = \scaforeSDK\Task\Task::getTaskId($folder_path);
        
        $cure_task_params = new \scaforeSDK\Task\UndoTaskParams();
        $cure_task_params->setFolder($folder_path);
        $cure_task_params->setTaskWorkDir(self::getTaskWorkDir($task_id));
        $cure_task_params->setUsername($folder->getOwner());
        $cure_task_params->setFilesForRestore([$sub_filepath]);
        $task = new \scaforeSDK\Task\UndoTask($task_id, $cure_task_params);
        if (\scaforeSDK\Task\TaskManager::addTask($task, \framework\TaskManager::QUEUE_TYPE_NON_WAIT)) {
            $folder_info->setCurrentWorkingTask($task::getTaskName());
            $folder_info->setState(\framework\Task::STATE_QUEUED);
            return self::waitSyncTask($task, 10);
        }
        Log::warn('RA--STH-SSUF ' . $folder_path . ' Cannot add task to queue');
        return false;
    }

    public static function startUndoForAllFiles(ScannableFolder $folder)
    {
        $folder_info = $folder->getFolderInfo();
        $folder_info->initInfo();
        
        $folder_path        = $folder_info->getFolder();
        $task_id            = \scaforeSDK\Task\Task::getTaskId($folder_path);
        
        $undo_task_params = new \scaforeSDK\Task\UndoTaskParams();
        $undo_task_params->setFolder($folder_path);
        $undo_task_params->setTaskWorkDir(self::getTaskWorkDir($task_id));
        $undo_task_params->setUsername($folder->getOwner());
        $undo_task_params->setRestoreAllFiles();
        $task = new \scaforeSDK\Task\UndoTask($task_id, $undo_task_params);
        if (\scaforeSDK\Task\TaskManager::addTask($task, \framework\TaskManager::QUEUE_TYPE_NORMAL)) {
            $folder_info->setCurrentWorkingTask($task::getTaskName());
            $folder_info->setState(\framework\Task::STATE_QUEUED);
            return true;
        }
        Log::warn('RA--STH-SUAF ' . $folder_path . ' Cannot add task to queue');
        return false;
    }

    public static function cancelTask(\RAISP\ScannableFolder $ra_folder)
    {
        $folder_info = $ra_folder->getFolderInfo();
        $folder_info->initInfo();
        $folder_path    = $folder_info->getFolder();
        $task_id        = \scaforeSDK\Task\Task::getTaskId($folder_path);
        if (\framework\Queue::delete($task_id)) {
            \framework\Task::setTaskState($task_id, \framework\Task::STATE_END);
            $folder_info->setState(\framework\Task::STATE_CANCELED);
            return;
        }
        $task_state = \framework\Task::getTaskState($task_id);
        if (!\framework\Task::isProcessTaskState($task_state)) {
            return;
        }
        \framework\Task::setTaskState($task_id, \framework\Task::STATE_CANCELED);
    }    
    
    // ===========================================================================
    
    private static function getTaskWorkDir($task_id)
    {
        return self::$result_folder . DIRECTORY_SEPARATOR . $task_id;
    }
    
    private static function waitSyncTask(\scaforeSDK\Task\Task $task, $timeout)
    {
        $start_time = time();
        while (!in_array($task->getState(), [\scaforeSDK\Task\Task::STATE_END, \scaforeSDK\Task\Task::STATE_CREATED]))
        {
            if (time() - $start_time > $timeout) {
                return false;
            }
            sleep(1);
        }
        return true;
    }
    
}