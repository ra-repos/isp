<?php

namespace RAISP;

class NotificationBuilder
{
    private $have_message           = false;
    private $have_working_domains   = false;
    private $cnt_infected           = 0;
    private $cnt_blacklisted        = 0;
    private $subject                = '';
    private $text                   = '';
    private $result                 = [];
    private $by_domain_mode         = true;
    
    public function __construct() 
    {
        if (Application::getAppMode() == Application::MODE_BY_DOMAIN) {
            $ra_folders = Domain::getAllDomain(true);
            $this->by_domain_mode = true;
        }
        else {
            $ra_folders = Client::getAllClients(true);
            $this->by_domain_mode = false;
        }
        
        foreach ($ra_folders as $ra_folder)
        {
            $folder_info = $ra_folder->getFolderInfo();
            $state = $folder_info->getState();
            if (\scaforeSDK\Task\Task::isProcessTaskState($state)) { 
                Log::info('RA--NB-C - send_notification.php: skip domain(' . $ra_folder->getName() . ')');
                $this->have_working_domains = true;
                return;
            }
    
            if ($state == \scaforeSDK\Task\Task::STATE_CANCELED
                || $state == \scaforeSDK\Task\Task::STATE_FAILED
            ) {
                continue;
            }
            
            $cnt_infected_files = $folder_info->getCountInfectedFiles();
            $have_blacklisted   = $folder_info->getBlacklistedGSB() 
                    || $folder_info->getBlacklistedVT() 
                    || $folder_info->getBlacklistedPH() 
                    || Application::langIsRU() && ($folder_info->getBlacklistedYSB() || $folder_info->getBlacklistedRK());
            
            $this->cnt_infected     += $cnt_infected_files  ? 1 : 0;
            $this->cnt_blacklisted  += $have_blacklisted    ? 1 : 0;
            
            $this->result[] = [
                'name'                  => $ra_folder->getName(),
                'cnt_infected_files'    => $cnt_infected_files,
                'have_blacklisted'      => $have_blacklisted,
            ];
        }
        if (!count($this->result)) {
            return;
        }   
        $this->have_message = true;
        $this->buildSubject();
        $this->buildText();
    }
    
    public function getSubject()
    {
        return $this->subject;
    }
    
    public function getText()
    {
        return $this->text;
    }
    
    public function haveMessage()
    {
        return $this->have_message;
    }
    
    public function haveWorkingDomains()
    {
        return $this->have_working_domains;
    }
    
    // ===============================================================
    
    private function buildSubject()
    {
        $this->subject      = Locale::getMessage('ra.email.subject');
        
        if ($this->cnt_infected) {
            $locale_key = $this->by_domain_mode ? 'ra.email.subject.infected' : 'ra.email.subject.by_user.infected';
            $this->subject .= Locale::getMessage($locale_key, ['cnt' => $this->cnt_infected]);
        }
        if ($this->cnt_blacklisted) {
            $locale_key = $this->by_domain_mode ? 'ra.email.subject.blacklisted' : 'ra.email.subject.by_user.blacklisted';
            $this->subject .= Locale::getMessage($locale_key, ['cnt' => $this->cnt_blacklisted]);
        }        
    }
    
    private function buildText()
    {
        $this->text = '<p>' . Locale::getMessage('ra.email.text_header') . '</p>' . "\n";
        if ($this->cnt_infected) {
            $this->buildInfectedMessage();
        }
        if ($this->cnt_blacklisted) {
            $this->buildBlacklistedMessage();
        }
        $this->text .=  '<p>' . Locale::getMessage('ra.email.text_footer') . '</p>' . "\n";        
    }
    
    private function buildInfectedMessage()
    {
        $header = $this->by_domain_mode ? Locale::getMessage('ra.email.text_header_infected') : Locale::getMessage('ra.email.by_user.text_header_infected');
        $this->text     .= '<p>' . $header . '</p>' . "\n";
        $this->text     .= '<ul type=square>' . "\n";
        foreach ($this->result as $object_params)
        {
            if (!$object_params['cnt_infected_files']) {
                continue;
            }
            $this->text .= '<li> ' . $object_params['name'] . ' - ' . Locale::getMessage('ra.email.text_domain', ['cnt' => $object_params['cnt_infected_files']]) . '</li>' . "\n";
        }
        $this->text .= '</ul>' . "\n";
    }

    private function buildBlacklistedMessage()
    {
        $this->text     .= '<p>' . Locale::getMessage('ra.email.text_header_blacklisted') . '</p>' . "\n";
        $this->text     .= '<ul type=square>' . "\n";
        foreach ($this->result as $object_params)
        {
            if (!$object_params['have_blacklisted']) {
                continue;
            }
            $this->text .= '<li> ' . $object_params['name'] . '</li>' . "\n";
        }
        $this->text .= '</ul>' . "\n";
    }
}
