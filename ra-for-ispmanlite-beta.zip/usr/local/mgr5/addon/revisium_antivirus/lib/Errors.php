<?php

namespace RAISP;

class Errors extends \scaforeSDK\Errors
{
    const ERROR_RAISP_NO_ACCESS  = 'raisp_no_access';
}
