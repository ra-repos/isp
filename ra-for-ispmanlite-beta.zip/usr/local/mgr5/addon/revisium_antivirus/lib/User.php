<?php

namespace RAISP;

class User
{
    const SALT = 'qUjtGnjkW5AwK6PrtAEg';
    
    private static $uuid = '';
    
    public static function getUUID()
    {
        if (!empty(self::$uuid)) {
            return self::$uuid;
        }
        $uuid = self::SALT;
        if (isset($_SERVER['AUTH_USER'])) {
            $uuid .= $_SERVER['AUTH_USER'];
        }
        if (isset($_SERVER['HTTP_COOKIE']) && preg_match('~ispmgrses\d*=([^\s]+)~i', $_SERVER['HTTP_COOKIE'], $m)) {
            $uuid .= $m[1];
        }
        else {
            $uuid .= isset($_SERVER['REMOTE_ADDR'])     ? $_SERVER['REMOTE_ADDR']       : '';
            $uuid .= isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT']   : '';
        }
        self::$uuid = sha1($uuid);
        return self::$uuid;
    }
}