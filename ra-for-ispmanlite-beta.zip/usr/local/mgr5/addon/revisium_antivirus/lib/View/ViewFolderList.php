<?php

namespace RAISP\View;

abstract class ViewFolderList extends ViewList
{
    const ICON_STATE_NONE       = '<state_none/>';
    const ICON_STATE_INFECTED   = '<state_infected />';
    const ICON_STATE_WARN       = '<state_warn />';
    const ICON_STATE_CLEAN      = '<state_clean />';
    const ICON_STATE_PROGRESS   = '<state_progress />';
    
    protected function renderPage($rows)
    {
        $this->sortRows($rows);
        
        $refresh_xml = '';
        if (self::needRefresh($rows)) {
            $refresh_xml = 'autoupdate="5"';
            \RAISP\Banners::setNotification(\RAISP\Locale::getMessage('ra.title.status'));
        }
        
        $template_name      = 'ra_domains';
        $select_mode_button = '<toolbtn name="by_user"     func="revisium_antivirus_by_user_func"      type="new" sametab="yes" img="t-users"      sprite="yes"></toolbtn>';
        if ($this instanceof ViewClientList) {
            $template_name      = 'ra_clients';
            $select_mode_button = '<toolbtn name="by_domain"   func="revisium_antivirus_by_domain_func"    type="new" sametab="yes" img="t-server-storages"    default="yes" sprite="yes"></toolbtn>';            
        }
        
        $template = new \RAISP\Template($template_name);
        $template->setParam('TABLE'                 , static::renderXMLStructure($rows));
        $template->setParam('REFRESH'               , $refresh_xml);
        $template->setParam('VERSION'               , \RAISP\Application::getVersion());
        $template->setParam('PROGRESS'              , '');
        $template->setParam('LICENSE'               , \RAISP\Application::hasLicense() ? \RAISP\Locale::getMessage('ra.title.premium') : \RAISP\Locale::getMessage('ra.title.free'));
        $template->setParam('BANNER'                , \RAISP\Banners::renderBanners());
        $template->setParam('LICENSE_BUTTON'        , \RAISP\Application::hasLicense() ? '' : '<toolbtn name="buy" func="plugin" type="new" img="t-payorder" sprite="yes"/>');
        $template->setParam('SELECT_MODE_BUTTON'    , $select_mode_button);
        
        self::addTemplateSort($template);
        return $template->build();        
    }
    
    
    protected static function getState(\scaforeSDK\FolderInfo $folder_info)
    {
        $state_str      = '';
        $color          = 'black';
        $state_icon     = self::ICON_STATE_NONE; 
        $have_infected  = false;
        $state_id       = 0;
        
        $state              = $folder_info->getState();
        $last_success_task  = $folder_info->getLastSuccessfulTask();
        if (is_null($state) || \scaforeSDK\Task\Task::isProcessTaskState($state)) {
            $state_str = '-';
        }
        elseif ($state == \scaforeSDK\Task\Task::STATE_FAILED || $state == \scaforeSDK\Task\Task::STATE_CANCELED && empty($last_success_task)) {
            $state_str = '-';
        }
        elseif ($folder_info->getCountInfectedFiles() > 0) {
            $state_str      = \RAISP\Locale::getMessage('ra.infected');
            $color          = 'red';
            $state_icon     = self::ICON_STATE_INFECTED; 
            $have_infected  = true;
            $state_id       = 3;
        }
        elseif ($folder_info->getCountCuredFiles() > 0) {
            $state_str  = \RAISP\Locale::getMessage('ra.label.cleaned');
            $state_icon = self::ICON_STATE_CLEAN;
            $color      = 'green';
        }
        else {
            $state_str  = \RAISP\Locale::getMessage('ra.label.clean');
            $state_icon = self::ICON_STATE_CLEAN; 
            $color      = 'green';
        }
        
        return [
            'state_icon'    => $state_icon,
            'state_str'     => $state_str,
            'state_id'      => $state_id,
            'color'         => $color,
            'have_infected' => $have_infected,
        ];
    }
    
    public static function isWorking(\scaforeSDK\FolderInfo $folder_info)
    {
        $state = $folder_info->getState();
        if (\scaforeSDK\Task\Task::isProcessTaskState($state)) {
            return true;
        }
        return false;
    }

    protected static function getThreats(\scaforeSDK\FolderInfo $folder_info)
    {
        $state              = $folder_info->getState();
        $cnt_infected_files = $folder_info->getCountInfectedFiles();
        $cnt_cured_files    = $folder_info->getCountCuredFiles();
        $last_success_task  = $folder_info->getLastSuccessfulTask();
        
        $threats_str = '-';
        if (is_null($state) || \scaforeSDK\Task\Task::isProcessTaskState($state)) {
            $threats_str = '-';
        }
        elseif ($state == \scaforeSDK\Task\Task::STATE_FAILED || $state == \scaforeSDK\Task\Task::STATE_CANCELED && empty($last_success_task)) {
            $threats_str = '-';
        }
        elseif ($cnt_infected_files) {
            $threats_str = $cnt_infected_files;
            if ($cnt_cured_files) {
                $threats_str .= ' (' . \RAISP\Locale::getMessage('ra.cleaned') . ' ' . $cnt_cured_files . ')';
            }
        }
        elseif ($cnt_cured_files) {
            $threats_str = \RAISP\Locale::getMessage('ra.cleaned_up') . ' ' . $cnt_cured_files;
        }
        
        return $threats_str;
    }

    protected static function getProgress(\scaforeSDK\FolderInfo $folder_info)
    {
        $state                  = $folder_info->getState();
        $percent                = $folder_info->getPercent();
        $stage                  = $folder_info->getStage();
        $current_working_task   = $folder_info->getCurrentWorkingTask();
        $last_successful_task   = $folder_info->getLastSuccessfulTask();
        $error_code             = $folder_info->getLastErrorCode();
        $in_work                = false;
        $in_queue               = false;
        $empty                  = false;
        $is_canceled            = false;
        $is_failed              = false;
        
        if (is_null($state)) {
            $empty = true;
        }
        elseif ($state == \scaforeSDK\Task\Task::STATE_RUNNING || $state == \scaforeSDK\Task\Task::STATE_WORKING) {
            $in_work = true;
        }
        elseif ($state == \scaforeSDK\Task\Task::STATE_QUEUED) {
            $in_queue = true;
        }
        elseif ($state == \scaforeSDK\Task\Task::STATE_CANCELED && empty($last_successful_task)) {
            $is_canceled = true;
        }
        elseif ($state == \scaforeSDK\Task\Task::STATE_FAILED) {
            $is_failed = true;
        }
        
        $progress = '';
        if ($empty) {
            $progress = '-';
        }
        elseif ($in_queue) {
            $progress = \RAISP\Locale::getMessage('ra.label.queued');
        }
        elseif ($in_work) {
            if (!$percent) {
                $progress = \RAISP\Locale::getMessage('ra.label.preparation');
                $progress .= ($stage == 'make_report') ? ' ( ' . \RAISP\Locale::getMessage('ra.label.report') . ' ) ' : '';
            }
            else {
                if ($current_working_task == \scaforeSDK\Task\Task::TASK_SCAN) {
                    $progress = \RAISP\Locale::getMessage('ra.label.scanning');
                }
                elseif ($current_working_task == \scaforeSDK\Task\Task::TASK_CURE) {
                    $progress = ($stage == 'backup') ? \RAISP\Locale::getMessage('ra.label.backuping') : \RAISP\Locale::getMessage('ra.label.cleaning');
                }
                elseif ($current_working_task == \scaforeSDK\Task\Task::TASK_UNDO) {
                    $progress = \RAISP\Locale::getMessage('ra.label.restoring');
                }
                $progress .= ' ' . round($percent, 1) . '%';
            }
        }
        else {
            $progress = \RAISP\Locale::getMessage('ra.label.scanned');
            if ($is_failed) {
                $progress = self::getStrError($folder_info);
            }
            elseif ($last_successful_task == \scaforeSDK\Task\Task::TASK_CURE) {
                $progress = \RAISP\Locale::getMessage('ra.label.cured');
            }
            elseif ($last_successful_task == \scaforeSDK\Task\Task::TASK_UNDO) {
                $progress = \RAISP\Locale::getMessage('ra.label.restored');
            }
            
            $updated_time = $folder_info->getReportCreateTime();
            
            if ($updated_time > 0 && !$is_failed && !$is_canceled) {
               $progress .= '  ' . date('d/m/Y H:i', $updated_time);
            } 
            elseif ($empty) {
               $progress = '';
            }
        }
        return $progress;
    }

    protected static function needRefresh($result_rows)
    {
        foreach ($result_rows as $result_row) 
        {
            if ($result_row['is_working']) {
                return true;
            }
        }
        return false;
    }
    
    protected static function getStrError(\scaforeSDK\FolderInfo $folder_info)
    {
        $last_error = $folder_info->getLastErrorCode();
        if (empty($last_error)) {
            return '';
        }
        elseif (isset(self::$errors[$last_error])) {
            return self::$errors[$last_error];
        }
        return \RAISP\Locale::getMessage('ra.label.error');
    }
    
}