<?php

namespace RAISP\View;

class ViewClientList extends ViewFolderList
{
    protected static $order_keyvalue_prefix   = 'clients_sort_user_';
    protected static $sort_params           = [
        'client'    => [
            'direction'     => self::SORT_ASC,
            'real_field'    => 'client',
        ],
        'state'     => [
            'direction'     => '',
            'real_field'    => 'state_id',
        ],
    ];
    
    // =======================================================
    
    public function render()
    {
        $ra_clients     = \RAISP\Client::getAllClients();
        $client_rows    = [];
        foreach ($ra_clients as $ra_client)
        {
            $client_rows[] = self::getClientResult($ra_client);
        }
        return $this->renderPage($client_rows);
    }
    
    // =======================================================
    
    protected static function renderXMLStructure($rows)
    {
        return array_reduce($rows, function ($result, $item) {
            $result .= '<elem>'
                . '<client>'                                    . htmlspecialchars($item['client'])         . '</client>' 
                . '<path>'                                      . htmlspecialchars($item['path'])           . '</path>'
                . '<state       color="' . $item['color'] .'">' . $item['state_str']                        . '</state>' 
                . '<threats     color="' . $item['color'] .'">' . $item['threats']                          . '</threats>' 
                . '<action>'                                    . $item['progress']                         . '</action>' 
                . '<hiddenstate>'                               . $item['state_str']                        . '</hiddenstate>' 
                . '<hidden_can_cure>'                           . (int)$item['can_cure']                    . '</hidden_can_cure>'
                . '<hidden_can_undo>'                           . (int)$item['can_undo']                    . '</hidden_can_undo>'
                . '<hidden_have_report>'                        . (int)$item['have_report']                 . '</hidden_have_report>'
                . $item['state_icon']
            . '</elem>' . "\n";
            return $result;
        });
    }
    
    private static function getClientResult(\RAISP\Client $ra_client)
    {
        $folder_info                    = $ra_client->getFolderInfo();
        $result                         = self::getState($folder_info);
        $result['is_working']           = self::isWorking($folder_info);
        $result['threats']              = self::getThreats($folder_info);
        $result['progress']             = self::getProgress($folder_info);
        $result['can_cure']             = $folder_info->canCure();
        $result['can_undo']             = $folder_info->canUndo();
        $result['have_report']          = $folder_info->haveReport();
        $result['client']               = $ra_client->getName();
        $result['path']                 = $ra_client->getPath();
        return $result;
    }
}