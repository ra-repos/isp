<?php

namespace RAISP\View;

abstract class ViewList extends View
{
    const SORT_ASC  = 'asc';
    const SORT_DESC = 'desc';
    
    protected static $errors = [];
    
    protected static $sort_params = [];

    public function __construct() 
    {
        self::$errors = [
            \RAISP\Errors::ERROR_RAISP_NO_ACCESS                => \RAISP\Locale::getMessage('errors.no_access'),
            \RAISP\Errors::ERROR_SCAFORE_OERATION_NO_CONDITIONS => \RAISP\Locale::getMessage('errors.no_condition'),
            \RAISP\Errors::ERROR_SCAFORE_OERATION_TIMEOUT       => \RAISP\Locale::getMessage('errors.timeout'),
            \RAISP\Errors::ERROR_SCAFORE_OERATION_FAILED        => \RAISP\Locale::getMessage('errors.operation_failed'),
        ];
    }

    public static function setOrderData($order_data)
    {
        if (empty($order_data)) {
            return;
        }
        \RAISP\KeyValueStorage::set(static::getKeyForKeyValueStorage(), $order_data, \RAISP\Application::getTTLSort());
    }
    
    protected function calcOrderField()
    {
        $field_data = \RAISP\KeyValueStorage::get(static::getKeyForKeyValueStorage(), '');
        if (empty($field_data)) {
            return;
        }
        
        $from0              = $field_data;
        $from1              = substr($field_data, 1);
        $direction          = substr($field_data, 0, 1) == 'a' ? self::SORT_DESC : self::SORT_ASC;
        $new_sort_params    = [];
        $need_replace       = false;
        
        foreach (static::$sort_params as $field_name => $field_params)
        {
            $new_sort_params[$field_name]               = $field_params;
            $new_sort_params[$field_name]['direction']  = '';
            
            if ($from0 == $field_name) {
                $new_sort_params[$field_name]['direction']  = self::SORT_ASC;
                $need_replace                               = true;
            }
            elseif ($from1 == $field_name) {
                $new_sort_params[$field_name]['direction']  = $direction;
                $need_replace                               = true;
            }
        }
        
        if ($need_replace) {
            static::$sort_params = $new_sort_params;
        }
    }    

    protected static function getKeyForKeyValueStorage()
    {
        return static::$order_keyvalue_prefix . \RAISP\User::getUUID();
    }
    
    protected function sortRows(&$rows)
    {
        $this->calcOrderField();
        $field      = '';
        $direction  = 1;
        foreach (static::$sort_params as $field_params)
        {
            $field_direction    = $field_params['direction'];
            $real_field         = $field_params['real_field'];
            if (!empty($field_direction)) {
                $field      = $real_field;
                $direction  = $field_direction == self::SORT_ASC ? 1 : -1;
                break;
            }
        }
        if (empty($field)) {
            return;
        }
        usort($rows, 
            function($a, $b) use ($field, $direction) {
                if ($a[$field] == $b[$field]) {
                    return 0;
                }
                return ($a[$field] > $b[$field]) ? $direction : $direction * -1;
            }
        );
    }    
    
    protected static function addTemplateSort(\RAISP\Template $template)
    {
        foreach (static::$sort_params as $field_name => $field_params)
        {
            $sort_html = '';
            if ($field_params['direction'] == self::SORT_ASC) {
                $sort_html = 'sorted="' . self::SORT_ASC . '"';
            }
            elseif ($field_params['direction'] == self::SORT_DESC) {
                $sort_html = 'sorted="' . self::SORT_DESC . '"';
            }
            $template->setParam('SORT_' . strtoupper($field_name), $sort_html);
        }        
    }
    
}