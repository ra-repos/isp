<?php

namespace RAISP\View;

class ViewDomainList extends ViewFolderList
{
    protected static $order_keyvalue_prefix = 'domains_sort_user_';
    protected static $sort_params           = [
        'name'          => [
            'direction'     => self::SORT_ASC,
            'real_field'    => 'name',
        ],
        'state'        => [
            'direction'     => '',
            'real_field'    => 'state_id',
        ],
        'owner'         => [
            'direction'     => '',
            'real_field'    => 'owner',
        ],
        'blacklisted'   => [
            'direction'     => '',
            'real_field'    => 'cnt_blacklisted',
        ],
    ];
    
    // =======================================================
    
    public function render()
    {
        $domains        = \RAISP\Domain::getAllDomain();
        $domains_rows   = [];
        foreach ($domains as $ra_domain)
        {
            $domains_rows[] = self::getDomainResult($ra_domain);
        }
        return $this->renderPage($domains_rows);
    }

    protected static function renderXMLStructure($rows)
    {
        return array_reduce($rows, function ($result, $item) {
            $result .= '<elem>'
                . '<name>'                                      . htmlspecialchars($item['name'])           . '</name>' 
                . '<value>'                                     . htmlspecialchars($item['doc_root'])       . '</value>'
                . '<owner>'                                     . htmlspecialchars($item['owner'])          . '</owner>'
                . '<blacklisted color="yellow">'                .                                             '</blacklisted>'
                . '<state       color="' . $item['color'] .'">' . $item['state_str']                        . '</state>' 
                . '<threats     color="' . $item['color'] .'">' . $item['threats']                          . '</threats>' 
                . '<action>'                                    . $item['progress']                         . '</action>' 
                . '<hiddenstate>'                               . $item['state_str']                        . '</hiddenstate>' 
                . '<hidden_can_cure>'                           . (int)$item['can_cure']                    . '</hidden_can_cure>'
                . '<hidden_can_undo>'                           . (int)$item['can_undo']                    . '</hidden_can_undo>'
                . '<hidden_have_report>'                        . (int)$item['have_report']                 . '</hidden_have_report>'
                . $item['blacklisted_icons']
                . $item['state_icon']
            . '</elem>' . "\n";
            return $result;
        });
    }    
    
    private static function getDomainResult(\RAISP\Domain $ra_domain)
    {
        $folder_info                    = $ra_domain->getFolderInfo();
        $result                         = self::getState($folder_info);
        $result['is_working']           = self::isWorking($folder_info);
        $result['threats']              = self::getThreats($folder_info);
        $result['progress']             = self::getProgress($folder_info);
        $result['can_cure']             = $folder_info->canCure() && \RAISP\Application::hasLicense();
        $result['can_undo']             = $folder_info->canUndo() && \RAISP\Application::hasLicense();
        $result['have_report']          = $folder_info->haveReport();
        $result['name']                 = $ra_domain->getName();
        $result['doc_root']             = $ra_domain->getDocRoot();
        $result['owner']                = $ra_domain->getOwner();
        $result['blacklisted_icons']    = self::getBlacklistedIcons($folder_info, $blacklisted, $cnt_blacklisted);
        $result['cnt_blacklisted']      = $cnt_blacklisted;
        if ($blacklisted && !$result['is_working'] && !$result['have_infected']) {
            $result['color']        = 'yellow';
            $result['state_icon']   = '<state_warn />';
            $result['state_str']    = \RAISP\Locale::getMessage('ra.blacklisted');
            $result['state_id']     = 2;
        }
        return $result;
    }
    
    private static function getBlacklistedIcons(\scaforeSDK\FolderInfo $folder_info, &$blacklisted = false, &$cnt_blacklisted = 0)
    {
        $cnt_blacklisted    = 0;
        $blacklisted        = false;
        $result             = '';
        if ($folder_info->getBlacklistedGSB()) {
            $result .= '<gsb/>';
            $blacklisted = true;
            $cnt_blacklisted++;
        }
        if (\RAISP\Application::langIsRU() && $folder_info->getBlacklistedYSB()) {
            $result .= '<ysb/>';
            $blacklisted = true;
            $cnt_blacklisted++;
        }
        if ($folder_info->getBlacklistedVT()) {
            $result .= '<vt/>';
            $blacklisted = true;
            $cnt_blacklisted++;
        }
        if ($folder_info->getBlacklistedPH()) {
            $result .= '<phish/>';
            $blacklisted = true;
            $cnt_blacklisted++;
        }
        if (\RAISP\Application::langIsRU() && $folder_info->getBlacklistedRK()) {
            $result .= '<rkn/>';
            $blacklisted = true;
            $cnt_blacklisted++;
        }
        return $result;
    }
}