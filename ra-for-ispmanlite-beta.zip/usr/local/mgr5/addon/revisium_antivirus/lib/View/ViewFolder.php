<?php

namespace RAISP\View;

abstract class ViewFolder extends View
{
    protected $ra_folder = null;
    
    public function __construct(\RAISP\ScannableFolder $ra_folder) 
    {
        $this->ra_folder = $ra_folder;
    }
}