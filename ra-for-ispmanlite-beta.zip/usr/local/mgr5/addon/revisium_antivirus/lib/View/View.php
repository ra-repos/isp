<?php

namespace RAISP\View;

abstract class View
{
    abstract public function render();
}
