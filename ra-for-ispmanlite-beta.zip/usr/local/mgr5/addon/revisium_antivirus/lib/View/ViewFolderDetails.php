<?php

namespace RAISP\View;

class ViewFolderDetails extends ViewFolder
{
    private $template_name = 'ra_details';
    
    private static $status_options  = [];
    private static $status_order    = [
        \scaforeSDK\Antivirus\CureReport::CURE_STATUS_CLEAR,     
        \scaforeSDK\Antivirus\CureReport::CURE_STATUS_NOT_READ,  
        \scaforeSDK\Antivirus\CureReport::CURE_STATUS_NOT_WRITE,
        \scaforeSDK\Antivirus\CureReport::CURE_STATUS_TOO_BIG,
        \scaforeSDK\Antivirus\CureReport::CURE_STATUS_CURED,
        \scaforeSDK\Antivirus\CureReport::CURE_STATUS_REMOVED,
    ];
    
    private static $type_order = [
        'srv',
        'cli',
    ];
    
    private static $index_types         = null;
    private static $replace_file_type   = [
        'php_mlw'       => 'srv',
        'js_mlw'        => 'cli',
        'redirect'      => '', //Redirect
        'phish'         => '',
        'adwr'          => '',
        '_big'          => '', //Big
        '_read_error'   => '', //Read error
        '_unknown'      => '', //Unknown

        /* Note! If you ad new file type you need to add property in xml to show icon */
    ];
    
    public function render() 
    {
        self::$status_options = [
            \scaforeSDK\Antivirus\CureReport::CURE_STATUS_INFECTED  => [\RAISP\Locale::getMessage('ra.label.infected')       , 'red'],
            \scaforeSDK\Antivirus\CureReport::CURE_STATUS_CURED     => [\RAISP\Locale::getMessage('ra.label.cleaned')        , 'green'],
            \scaforeSDK\Antivirus\CureReport::CURE_STATUS_REMOVED   => [\RAISP\Locale::getMessage('ra.label.removed')        , 'green'],
            \scaforeSDK\Antivirus\CureReport::CURE_STATUS_NOT_WRITE => [\RAISP\Locale::getMessage('ra.label.not_written')    , 'red'],
            \scaforeSDK\Antivirus\CureReport::CURE_STATUS_NOT_READ  => [\RAISP\Locale::getMessage('ra.label.unknown')        , 'red'],
            \scaforeSDK\Antivirus\CureReport::CURE_STATUS_CLEAR     => [\RAISP\Locale::getMessage('ra.label.unknown')        , 'red'],
            \scaforeSDK\Antivirus\CureReport::CURE_STATUS_TOO_BIG   => [\RAISP\Locale::getMessage('ra.label.unknown')        , 'red'],
        ];
        $template = new \RAISP\Template($this->template_name);
        $template->setParams([
            'TABLE' => $this->renderBlacklisted($this->ra_folder) . $this->renderTable($this->ra_folder),
            'NAME'  => $this->ra_folder->getName(),
        ]);
        return $template->build();
    }
    
    // ==================================================
    
    private function renderTable(\RAISP\ScannableFolder $ra_folder)
    {
        $folder_info    = $ra_folder->getFolderInfo();
        $files_report   = $folder_info->getFilesReport();
        $rows           = [];
        foreach ($files_report as $hash => $scan_info) 
        {
            $rows[] = $this->getRow($hash, $scan_info);
        }
        $this->sortRows($rows);
        return $this->renderXMLStructure($rows);
    }
    
    private function getRow($hash, $file_info)
    {
        $fn             = $file_info['filepath'];
        $snippet        = $file_info['snippet'];
        $types          = $file_info['type'];
        $size           = $file_info['size'];
        $modif_time     = $file_info['modif_time'];
        $sigid          = $file_info['sigid'];
        $signature      = $file_info['signature'];
        $cure_status    = (int)$file_info['cure_status'];
        
        $fn_short           = substr($fn, -50, 50);
        $truncate_fn        = ($fn_short != $fn ? '...' : '') . htmlspecialchars($fn_short);
        $snippet            = preg_replace('~^\[\d+\]~' , '', $snippet);
        $snippet            = preg_replace('~@!!!>~'    , '', $snippet);
        $replaced_types     = array_reduce($types, 'self::replaceType');
        $types_view         = implode(', ', array_keys($replaced_types));
        $cure_status_str    = self::getLocaleStatus($cure_status);
        //$was_modif          = in_array($cure_status, [\scaforeSDK\Antivirus\CureReport::CURE_STATUS_CURED, \scaforeSDK\Antivirus\CureReport::CURE_STATUS_REMOVED]);
        
        return [
            'id'            => $this->ra_folder->getName() . ',' . $hash,
            'types_view'    => $types_view, 
            'truncate_fn'   => $truncate_fn,
            'snpt'          => htmlspecialchars($snippet),
            'size'          => htmlspecialchars($size),
            'mt'            => date('Y-m-d', $modif_time),
            'sig'           => $signature,
            'deleted'       => (int)($cure_status == \scaforeSDK\Antivirus\CureReport::CURE_STATUS_REMOVED),
            'cure_color'    => $this->getLocaleColor($cure_status),
            'can_cure'      => (int)!$cure_status,
            'can_undo'      => (int)$cure_status,
            'cure_type'     => $cure_status_str,
            'sort_field'    => $this->getFileTypeIndexForOrder($types_view) . $sigid,//(int)array_search($cure_status, self::$status_order)
        ];
    }
    
    private function renderBlacklisted(\RAISP\ScannableFolder $ra_folder)
    {
        if (!$ra_folder instanceof \RAISP\Domain) {
            return '';
        }
        $blacklisted_data = \scaforeSDK\Blacklisted\BlacklistedCache::get($ra_folder->getNameInPunyCode(), null);
        if (is_null($blacklisted_data) || !\RAISP\Application::getCheckBlacklisted()) {
            return '';
        }
        $blacklisted    = new \scaforeSDK\Blacklisted\Blacklisted($blacklisted_data);
        $gsb            = $blacklisted->BlacklistedGSB();
        $ysb            = $blacklisted->BlacklistedYSB();
        $vt             = $blacklisted->BlacklistedVT();
        $rk             = $blacklisted->BlacklistedRK();
        $ph             = $blacklisted->BlacklistedPH();

        $rows   = [];
        if ($gsb) {
            $rows[] = [
                'types_view'     => 'bl',
                'truncate_fn'   => \RAISP\Locale::getMessage('ra.blacklisted.google_blacklisted'),
                'snpt'          => ucwords(str_replace('_', ' ', $gsb['virus_type'])),
                'mt'            => date('Y-m-d', $gsb['cached']),
            ];
        }
        if (\RAISP\Application::langIsRU()) {
            if ($ysb) {
                $rows[] = [
                    'types_view'     => 'bl',
                    'truncate_fn'   => \RAISP\Locale::getMessage('ra.blacklisted.yandex_blacklisted'),
                    'snpt'          => ucwords($ysb['virus_type']),
                    'mt'            => date('Y-m-d', $ysb['cached']),
                ];
            }
            if ($rk) {
                $rk_info = ($rk['info'] == \scaforeSDK\Blacklisted\Blacklisted::RK_HOST ? \RAISP\Locale::getMessage('ra.blacklisted.host_rkn') : \RAISP\Locale::getMessage('ra.blacklisted.ip_rkn'));
                $rows[] = [
                    'types_view'    => 'bl',
                    'truncate_fn'   => \RAISP\Locale::getMessage('ra.blacklisted.rkn') . ': ' . $rk_info,
                    'snpt'          => isset($rk['url']) ? $rk['url'] : '',
                    'mt'            => date('Y-m-d', $rk['cached']),
                ];
            }
        }
        if ($vt) {
            $rows[] = [
                'types_view'     => 'bl',
                'truncate_fn'   => \RAISP\Locale::getMessage('ra.blacklisted.vt'),
                'snpt'          => implode(', ', $vt['service_vir_found']),
                'mt'            => date('Y-m-d', $vt['cached']),
            ];
        }
        if ($ph) {
            $rows[] = [
                'types_view'     => 'bl',
                'truncate_fn'   => \RAISP\Locale::getMessage('ra.blacklisted.ph'),
                'snpt'          => $ph['url'],
                'mt'            => date('Y-m-d', $ph['time_detected']),
            ];
        }
        return $this->renderXMLStructure($rows, 'red');
    }
    
    private function renderXMLStructure($rows, $color = '')
    {
        $set_color = $color ? ' color="' . $color . '"' : '';
        return array_reduce($rows, function ($result, $item) use ($set_color) {
            $set_cure_color = isset($item['cure_color']) ? ' color="' . $item['cure_color'] . '"' : $set_color;
            $result .= '<elem>' . 
                    '<id'       . $set_color        . '>'  . (isset($item['id'])           ? $item['id']           : '')    . '</id>' .
                    '<type'     . $set_color        . '>'  . (isset($item['types_view'])   ? /*$item['types_view']*/'' : '')   . '</type>' .
                    '<path'     . $set_color        . '>'  . (isset($item['truncate_fn'])  ? $item['truncate_fn']  : '')    . '</path>' . 
                    '<snippet'  . $set_color        . '>'  . (isset($item['snpt'])         ? $item['snpt']         : '')    . '</snippet>' . 
                    '<size'     . $set_color        . '>'  . (isset($item['size'])         ? $item['size']         : '')    . '</size>' . 
                    '<sig'      . $set_color        . '>'  . (isset($item['sig'])          ? $item['sig']          : '')    . '</sig>' . 
                    '<cure'     . $set_cure_color   . '>'  . (isset($item['cure_type'])    ? $item['cure_type']    : '')    . '</cure>' . 
                    '<time'     . $set_color        . '>'  . (isset($item['mt'])           ? $item['mt']           : '')    . '</time>' . 
                    '<can_cure>'. (isset($item['can_cure']) ? (int)$item['can_cure']    : '')   . '</can_cure>' . 
                    '<can_undo>'. (isset($item['can_undo']) ? (int)$item['can_undo']    : '')   . '</can_undo>' . 
                    '<deleted>' . (isset($item['deleted'])  ? (int)$item['deleted']     : '')   . '</deleted>' . 
                    '<type_' . (isset($item['types_view'])  ? $item['types_view']   : '') . '/>' . 
                '</elem>';            
            return $result;
        });
    }
    
    private static function replaceType($return, $value)
    {
        if (isset(self::$replace_file_type[$value])) {
            $return[self::$replace_file_type[$value]] = 1;
        }
        return $return;
    }
    
    private function sortRows(&$rows)
    {
        usort($rows, 
            function($a, $b) {
                if ($a['sort_field'] == $b['sort_field']) {
                    return 0;
                }
                return ($a['sort_field'] > $b['sort_field']) ? 1 : -1;
            }
        );
    }    
    
    private function getFileTypeIndexForOrder($type)
    {
        if (is_null(self::$index_types)) {
            self::$index_types = [];
            $i = 0;
            foreach (self::$replace_file_type as $ftype)
            {
                self::$index_types[$ftype] = $i;
                $i++;
            }
        }
        return isset(self::$index_types[$type]) ? self::$index_types[$type] : count(self::$index_types);
    }    
    
    private function getLocaleStatus($status)
    {
        return isset(self::$status_options[$status]) ? self::$status_options[$status][0] : $status;
    }
    
    private function getLocaleColor($status)
    {
        return isset(self::$status_options[$status]) ? self::$status_options[$status][1] : 'green';
    }
    
}
