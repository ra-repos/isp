<?php

include_once __DIR__ . DIRECTORY_SEPARATOR . 'common.php';

/////////////////////////////////////////////////////////

$func       = @$_SERVER['ACTION_NAME'];
$elid       = @$_SERVER['PARAM_elid'];
$sok        = @$_SERVER['PARAM_sok'];
$item       = @$_SERVER['PARAM_item'];
$col        = @$_SERVER['PARAM_p_col'];
$elname     = @$_SERVER['PARAM_elname'];

if (!RAISP\Client::currentUserIsAdmin()) {
    noAccessPage();
}

$app_mode   = RAISP\Application::getAppMode();
$by_user    = false;
$by_domain  = false;
if ($app_mode == RAISP\Application::MODE_BY_USER) {
    $by_user = true;
}
elseif ($app_mode == RAISP\Application::MODE_BY_DOMAIN) {
    $by_domain = true;
}

/////////////////////////////////////////////////////////
$xml_main = '';

// ****************************************************
if ($func == 'revisium_antivirus_scan_all_func') {
    \RAISP\Log::info('AJAX - ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: scan_all');
    $ra_folders = $by_domain ? \RAISP\Domain::getAllDomain() : \RAISP\Client::getAllClients();
    foreach ($ra_folders as $ra_folder) 
    {
        \RAISP\ScaforeTaskHelper::startScan($ra_folder);
    }
    showMainPage();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_cancel_all_func') {
    \RAISP\Log::info('AJAX - ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: cancel_all');
    $ra_folders = $by_domain ? \RAISP\Domain::getAllDomain() : \RAISP\Client::getAllClients();
    $ra_folders = array_reverse($ra_folders);
    foreach ($ra_folders as $ra_folder) 
    {
        \RAISP\ScaforeTaskHelper::cancelTask($ra_folder);
    }
    showMainPage();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_scan_func') {
    \RAISP\Log::info('AJAX ' . $elid . ' ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: scan');
    $ra_folder = $by_domain ? \RAISP\Domain::getDomainByDomainName($elid) : \RAISP\Client::getClientByName($elid);
    if (!empty($ra_folder)) {
        \RAISP\ScaforeTaskHelper::startScan($ra_folder);
    }
    showMainPage();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_cleanup_func') {
    \RAISP\Log::info('AJAX ' . $elid . ' ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: cure');
    if (RAISP\Application::hasLicense()) {
        $ra_folder = $by_domain ? RAISP\Domain::getDomainByDomainName($elid) : RAISP\Client::getClientByName($elid);
        if (!empty($ra_folder)) {
            \RAISP\ScaforeTaskHelper::startCureForAllFiles($ra_folder);
        }
    }
    else {
        RAISP\Banners::setWarning(RAISP\Locale::getMessage('ra.title.license.warn'));
    }
    showMainPage();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_cleanup_file_func') {
    \RAISP\Log::info('AJAX ' . $elid . ' ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: cure file');
    $ra_folder      = null;
    $sub_filepath   = '';
    getRAFolderAndSubFilepath($by_domain, $elid, $ra_folder, $sub_filepath);
    
    if (!empty($ra_folder) && \RAISP\Application::hasLicense()) {
        if (\RAISP\ScaforeTaskHelper::startSyncCureForFile($ra_folder, $sub_filepath)) {
            $xml_main = (new RAISP\View\ViewFolderDetails($ra_folder))->render();
        }
        else {
            RAISP\Banners::setWarning(RAISP\Locale::getMessage('ra.title.cure_file_error'));
            showMainPage();
        }
    }
    else {
        RAISP\Banners::setWarning(RAISP\Locale::getMessage('ra.title.license.warn'));
        showMainPage();
    }
    
}
// ****************************************************
elseif ($func == 'revisium_antivirus_undo_func') {
    \RAISP\Log::info('AJAX ' . $elid . ' ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: undo');
    if (RAISP\Application::hasLicense()) {
        $ra_folder = $by_domain ? RAISP\Domain::getDomainByDomainName($elid) : RAISP\Client::getClientByName($elid);
        if (!empty($ra_folder)) {
            \RAISP\ScaforeTaskHelper::startUndoForAllFiles($ra_folder);
        }
    }
    else {
        RAISP\Banners::setWarning(RAISP\Locale::getMessage('ra.title.license.warn'));
    }
    showMainPage();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_undo_file_func') {
    \RAISP\Log::info('AJAX ' . $elid . ' ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: cure file');
    $ra_folder      = null;
    $sub_filepath   = '';
    getRAFolderAndSubFilepath($by_domain, $elid, $ra_folder, $sub_filepath);
    if (!empty($ra_folder) && \RAISP\Application::hasLicense()) {
        if (\RAISP\ScaforeTaskHelper::startSyncUndoForFile($ra_folder, $sub_filepath)) {
            $xml_main = (new RAISP\View\ViewFolderDetails($ra_folder))->render();
        }
        else {
            RAISP\Banners::setWarning(RAISP\Locale::getMessage('ra.title.undo_file_error'));
            showMainPage();
        }
    }
    else {
        RAISP\Banners::setWarning(RAISP\Locale::getMessage('ra.title.license.warn'));
        showMainPage();
    }
}
// ****************************************************
elseif ($func == 'revisium_antivirus_details_func') {
    \RAISP\Log::info('AJAX ' . $elid . ' ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: details');
    $ra_folder = $by_domain ? RAISP\Domain::getDomainByDomainName($elid) : RAISP\Client::getClientByName($elid);
    if (empty($ra_folder)) {
        showMainPage();
    }
    $xml_main = (new RAISP\View\ViewFolderDetails($ra_folder))->render();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_remove_backup_func') {
    \RAISP\Log::info('AJAX ' . $elid . ' ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: details');
    getRAFolderAndSubFilepath($by_domain, $elid, $ra_folder, $sub_filepath);
    if (empty($ra_folder)) {
        showMainPage();
    }
    $folder_info = $ra_folder->getFolderInfo();
    \scaforeSDK\BackupHelper::removeBackup($folder_info);
    $xml_main = (new RAISP\View\ViewFolderDetails($ra_folder))->render();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_settings_func') {
    $template = new RAISP\Template('ra_settings');
    $ra_settings = new RAISP\Settings();
    $template->setParam('CONFIG', $ra_settings->getXML());
    $template->setParam('BANNER', RAISP\Banners::renderBanners());
    $xml_main = $template->build();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_about_func') {
    $template = new RAISP\Template('ra_about');
    $template->setParam('VERSION'           , RAISP\Application::getVersion());
    $template->setParam('DESCRIPTION'       , htmlspecialchars(RAISP\Locale::getMessage('ra.about.description')));
    $template->setParam('LICENSE'           , RAISP\Application::hasLicense() ? RAISP\Locale::getMessage('ra.title.premium') : RAISP\Locale::getMessage('ra.title.free'));
    $template->setParam('LICENSE_BUTTON'    , RAISP\Application::hasLicense() ? '' : '<toolbtn name="buy" func="plugin" type="new" img="t-payorder" sprite="yes"/>');

    $xml_main = $template->build();
}

// ****************************************************
elseif ($func == 'revisium_antivirus_show_file_func') {
    $ra_folder      = null;
    $sub_filepath   = '';
    getRAFolderAndSubFilepath($by_domain, $elid, $ra_folder, $sub_filepath);
    
    $filepath       = $ra_folder->getPathForCheck() . DIRECTORY_SEPARATOR . $sub_filepath;
    $file_dirpath   = dirname($filepath);
    $filename       = basename($sub_filepath);
    $xmlstr         = RAISP\Application::getStdin();
    $query          = 'elid=' . urlencode($filename) . '&plid=' . urlencode($file_dirpath) . '&func=file.edit';
    $xml            = new SimpleXMLElement($xmlstr);
    $ok             = $xml->addChild('ok', htmlspecialchars($query, ENT_XML1, 'UTF-8'));
    $ok->addAttribute('type', 'list');
    $xml_main = $xml->asXML();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_func' && !empty($col)) {
    \RAISP\Log::info('AJAX ' . $col . ' ' . ($by_domain ? 'D' : 'U') . ' ra_addon.php: set order');
    if ($by_domain) {
        \RAISP\View\ViewDomainList::setOrderData($col);
    }
    else {
        \RAISP\View\ViewClientList::setOrderData($col);
    }
    showMainPage();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_by_user_func') {
    \RAISP\Log::info('AJAX ' . $func . ' ra_addon.php: switch mode');
    \RAISP\Application::setAppMode(\RAISP\Application::MODE_BY_USER);
    \RAISP\Banners::setNotification(\RAISP\Locale::getMessage('ra.banner.change_mode'));
    showMainPage();
}
// ****************************************************
elseif ($func == 'revisium_antivirus_by_domain_func') {
    \RAISP\Log::info('AJAX ' . $func . ' ra_addon.php: switch mode');
    \RAISP\Application::setAppMode(\RAISP\Application::MODE_BY_DOMAIN);
    \RAISP\Banners::setNotification(\RAISP\Locale::getMessage('ra.banner.change_mode'));
    showMainPage();
}
// ****************************************************
else {
    showMainPage();
}
    
echo $xml_main;

// ======================================================

function noAccessPage()
{
    RAISP\Banners::setNotification(RAISP\Locale::getMessage('ra.banner.no_access'));
    $template = new RAISP\Template('ra_no_access');
    $template->setParam('BANNER', RAISP\Banners::renderBanners());
    echo $template->build();
    exit;
}

function showMainPage()
{
    if (RAISP\Application::getAppMode() == RAISP\Application::MODE_BY_DOMAIN) {
        echo (new RAISP\View\ViewDomainList())->render();
    }
    else {
        echo (new RAISP\View\ViewClientList())->render();
    }
    exit;
}

function getRAFolderAndSubFilepath($by_domain, $elid, &$ra_folder = null, &$sub_filepath = '')
{
    list($object_name, $file_id) = explode(',', $elid, 2);
    $ra_folder = $by_domain ? RAISP\Domain::getDomainByDomainName($object_name) : RAISP\Client::getClientByName($object_name);
    if ($ra_folder === false) {
        showMainPage();
    }
    $report = $ra_folder->getFolderInfo()->getFilesReport();
    if (!isset($report[$file_id])) {
        showMainPage();
    }
    $sub_filepath = $report[$file_id]['filepath'];
}
