<?php

ini_set('display_errors', 0);

$DS     = DIRECTORY_SEPARATOR;
$MB     = 1048576;
$DAY    = 86400;
$MONTH  = 31 * $DAY;

include __DIR__ . $DS . 'autoload.php';

define('RA_PHP_HANDLER'             , '/opt/php71/bin/php'); 
define('RA_PHP_INI'                 , __DIR__ . $DS . 'php.ini');
define('RA_CLASSES'                 , __DIR__ . $DS . 'lib');
define('RA_SERVICES'                , __DIR__ . $DS . 'services');
define('RA_TEMPLATE_FOLDER'         , __DIR__ . $DS . 'xml');
define('RA_MAIN_DATA_FOLDER'        , $DS . 'usr' . $DS . 'local' . $DS . 'mgr5' . $DS . 'var' . $DS . 'raisp_data');

define('RA_BACKUP_FOLDER'           , RA_MAIN_DATA_FOLDER . $DS . 'backups');
define('RA_LOG_FOLDER'              , RA_MAIN_DATA_FOLDER . $DS . 'log');
define('RA_TASKS_FOLDER'            , RA_MAIN_DATA_FOLDER . $DS . 'cache' . $DS . 'tasks');
define('RA_QUEUE_FOLDER'            , RA_MAIN_DATA_FOLDER . $DS . 'cache' . $DS . 'queue');
define('RA_DATA_FOLDER'             , RA_MAIN_DATA_FOLDER . $DS . 'data');// данные для keyValueStorage
define('RA_DB_FOLDER'               , RA_MAIN_DATA_FOLDER . $DS . 'db');
define('RA_LISTS_FOLDER'            , RA_MAIN_DATA_FOLDER . $DS . 'lists');
define('RA_LOCK_FOLDER'             , RA_MAIN_DATA_FOLDER . $DS . 'lock');
define('RA_RESULT_FOLDER'           , RA_MAIN_DATA_FOLDER . $DS . 'result');// тут будут лежать данные по Объектам и по файлам
define('RA_TMP_FOLDER'              , RA_MAIN_DATA_FOLDER . $DS . 'tmp');

include RA_CLASSES . $DS . 'Locales'. $DS . 'ru-RU.php';
include RA_CLASSES . $DS . 'Locales'. $DS . 'en-EN.php';

$system_timezone_file = '/etc/timezone';
if (@file_exists($system_timezone_file)) {
    $content_timezone_file = @file_get_contents('/etc/timezone');
    $content_timezone_file = trim($content_timezone_file);
    @date_default_timezone_set($content_timezone_file);
}

//=================================================================

RAISP\Template                          ::setFolder(RA_TEMPLATE_FOLDER);
RAISP\ScaforeTaskHelper                 ::setResultFolder(RA_RESULT_FOLDER);
\RAISP\EmailChecker                     ::setCheckerScriptFilepth(RA_SERVICES . $DS . 'email_checker.php');
framework\Locker                        ::setFolder(RA_LOCK_FOLDER);
framework\KeyValueStorage               ::setFolder(RA_DB_FOLDER);
framework\Task                          ::setFolder(RA_TASKS_FOLDER);
framework\Log                           ::setFolder(RA_LOG_FOLDER);
framework\Log                           ::setLogLevel(\RAISP\Application::getLogLevel());
framework\KeyListStorage                ::setFolder(RA_DB_FOLDER);
framework\Queue                         ::setDataFolder(RA_QUEUE_FOLDER);
scaforeSDK\FilesMetaInfo                ::setDBFolder(RA_LISTS_FOLDER);
scaforeSDK\FoldersInfoStorage           ::setFolder(RA_DB_FOLDER);
scaforeSDK\Task\Task                    ::setTaskExecutorScriptPath(RA_SERVICES . $DS . 'task_executor.php');
scaforeSDK\Task\Task                    ::setPHPHandler(RA_PHP_HANDLER);
scaforeSDK\Task\Task                    ::setPHPINI(RA_PHP_INI);
scaforeSDK\Task\Task                    ::setBackupFolder(RA_BACKUP_FOLDER);
scaforeSDK\Task\TaskParams              ::setPHPHandlerFilepath(RA_PHP_HANDLER);
scaforeSDK\Task\TaskParams              ::setPHPINIFilepath(RA_PHP_INI);
scaforeSDK\Antivirus\Antivirus          ::setProcessLog(RA_LOG_FOLDER . $DS . 'process.log');
scaforeSDK\Task\ScanTask                ::setScanTimeout(\RAISP\Application::getScanTimeout());
scaforeSDK\Task\CureTask                ::setCureTimeout(\RAISP\Application::getCureTimeout());
scaforeSDK\Task\TaskManager             ::setExecutorTimeout(\RAISP\Application::getExecutorTimeout());
scaforeSDK\Task\TaskManager             ::setExecutorLog(RA_LOG_FOLDER . $DS . 'executor.log');
scaforeSDK\Antivirus\Mover              ::setScriptPath(RA_SERVICES . $DS . 'mover.php');
scaforeSDK\Blacklisted\BlacklistedCache ::setCacheFolder(RA_DATA_FOLDER);

\framework\Cleaner::addFolderForCleanup(RA_BACKUP_FOLDER, $MONTH);
\framework\Cleaner::addFolderForCleanup(RA_TASKS_FOLDER , $MONTH);
\framework\Cleaner::addFolderForCleanup(RA_LISTS_FOLDER , $MONTH);
\framework\Cleaner::addFolderForCleanup(RA_DATA_FOLDER  , $MONTH);
\framework\Cleaner::addFolderForCleanup(RA_RESULT_FOLDER, $MONTH);
\framework\Cleaner::addFolderForCleanup(RA_TMP_FOLDER   , $MONTH);
\framework\Cleaner::addFolderForCleanup(RA_LOG_FOLDER   , $MONTH);
\framework\Cleaner::addFolderForRotate(RA_LOG_FOLDER, 10 * $MB, 9);
