<?php

spl_autoload_register(function ($class) {
    $DS     = DIRECTORY_SEPARATOR;
    $resplaces = [
        'RAISP\\'   => '',
    ];
    $resplaces['\\'] = $DS;
    $path   = __DIR__ . $DS . 'lib' . $DS . $class . '.php';
    $path   = str_replace(array_keys($resplaces) , array_values($resplaces), $path);
    if (file_exists($path)) {
        require_once $path;
    }
});

include __DIR__ . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'scaforeSDK' . DIRECTORY_SEPARATOR . 'autoload.php';
include __DIR__ . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'framework' . DIRECTORY_SEPARATOR . 'autoload.php';
