#!/opt/php71/bin/php
<?php

include_once __DIR__ . DIRECTORY_SEPARATOR . 'revisium_antivirus' . DIRECTORY_SEPARATOR . 'common.php';

$cmd = RA_PHP_HANDLER . ' -c ' . RA_PHP_INI . ' ' . '/usr/local/mgr5/addon/revisium_antivirus/ra_addon.php';
putenv('RA_STDIN=' . getStdin());
passthru($cmd);

// ============================================

function getStdin()
{
    $stdin  = '';
    $f      = @fopen('php://stdin', 'r');
    while($line = fgets($f)) 
    {
        $stdin .= $line;
    }
    fclose($f);
    return $stdin;
}

