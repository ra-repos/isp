#!/opt/php71/bin/php
<?php

include __DIR__ . '/revisium_antivirus/common/config.php';

$php_ini_file   = RA_PHP_INI;
$php_handler    = RA_PHP_HANDLER;
$ra_addon_file  = '/usr/local/mgr5/addon/revisium_antivirus/ra_addon.php';

$cmd = $php_handler . ' -c ' . $php_ini_file . ' ' . $ra_addon_file;

putenv('RA_STDIN=' . getStdin());

passthru($cmd);

// ============================================

function getStdin()
{
    $stdin  = '';
    $f      = @fopen('php://stdin', 'r');
    while($line = fgets($f)) 
    {
        $stdin .= $line;
    }
    fclose($f);
    return $stdin;
}

