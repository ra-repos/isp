#!/opt/php71/bin/php
<?php

$allowed_isp_actions = [
    'admin',
    'webdomain', 
    'user',
    'domain',
    'backup2.superlist',
    'db',
    'backup2.superlist.import',
    'shell',
    'reboot_confirm',
    'journal',
    'authlog',
    'netactconn',
    'adminstat',
    'dismiss',
];

$dismiss_allowed_pid = [
    'email_notif_banner',
    'infected_banner',
];

$xml            = getStdin();
$func           = isset($_SERVER['ACTION_NAME'])    ? $_SERVER['ACTION_NAME']   : '';
$pid            = isset($_SERVER['PARAM_id'])       ? $_SERVER['PARAM_id']      : '';
$isp_request    = in_array($func, $allowed_isp_actions);

$DS     = DIRECTORY_SEPARATOR;
define('RA_MAIN_DATA_FOLDER'    , $DS . 'usr' . $DS . 'local' . $DS . 'mgr5' . $DS . 'var' . $DS . 'raisp_data');
define('RA_TMP_FOLDER'          , RA_MAIN_DATA_FOLDER . $DS . 'tmp');
define('RA_LOG_FOLDER'          , RA_MAIN_DATA_FOLDER . $DS . 'log');
define('BANNER_JSON_FILEPATH'   , RA_TMP_FOLDER . $DS . 'banners.json');
define('EXEC_LOGGING'           , 0); // [1 FOR TEST]

if (!$isp_request && strpos($func, 'revisium_antivirus_') !== 0
    || $func == 'dismiss' && !in_array($pid, $dismiss_allowed_pid)
    || $isp_request && (!file_exists(BANNER_JSON_FILEPATH) || filesize(BANNER_JSON_FILEPATH) < 3)
) {
    echo $xml;
    exit;
}
if ($isp_request && strlen($xml) > 131072) {
    addToLog('Big size xml func=' . $func . ' size=' . strlen($xml));
    echo $xml;
    exit;
}

include_once __DIR__ . DIRECTORY_SEPARATOR . 'revisium_antivirus' . DIRECTORY_SEPARATOR . 'common.php';

$log_postfix = '';
if (EXEC_LOGGING) {
    $log_filepath   = RA_LOG_FOLDER . DIRECTORY_SEPARATOR . 'ra_addon.log';
    $log_postfix    = ' 2>> ' . $log_filepath;
}
$cmd            = RA_PHP_HANDLER . ' -c ' . RA_PHP_INI . ' ' . '/usr/local/mgr5/addon/revisium_antivirus/ra_addon.php' . $log_postfix;
putenv('RA_STDIN='          . $xml);
putenv('RA_ISP_REQUEST='    . (int)$isp_request);
passthru($cmd);

// ============================================

function getStdin()
{
    $stdin  = '';
    $f      = @fopen('php://stdin', 'r');
    while($line = fgets($f)) 
    {
        $stdin .= $line;
    }
    fclose($f);
    return $stdin;
}

function getPrettyXML($xml_str)
{
    $file_name = '/tmp/tmp_xml' . crc32(time() . rand(1, 100000)) . '.xml';
    $domxml = new DOMDocument('1.0');
    $domxml->preserveWhiteSpace = false;
    $domxml->formatOutput = true;
    $domxml->loadXML($xml_str);
    $domxml->save($file_name);
    $xmlp = file_get_contents($file_name);
    unlink($file_name);
    return $xmlp;
}

function addToLog($message)
{
    $log_filepath   = RA_LOG_FOLDER . DIRECTORY_SEPARATOR . 'wrapper.log';
    $string         = '[' . date('Y.m.d G:i:s') . '] ' . $message . "\n";
    file_put_contents($log_filepath, $string, FILE_APPEND);
}