#!/bin/bash

ps ax | grep "scafore/queue.php" | grep -v "grep" | awk '{system("kill -9 " $1)}'

rm -f  /etc/cron.d/revisium
rm -rf /usr/local/mgr5/var/ra_data
rm -rf /usr/local/mgr5/var/scafore
rm -rf /usr/local/mgr5/addon/revisium_antivirus
rm -f /usr/local/mgr5/addon/ra_php_wrapper.php
rm -f /usr/local/mgr5/etc/xml/ispmgr_mod_ra.xml
rm -f /usr/local/mgr5/skins/common/img/t-revisiumantivirus-s.png
rm -f /usr/local/mgr5/skins/common/img/t-revisiumantivirus.png
rm -f /usr/local/mgr5/skins/common/plugin-logo/ispmanager-plugin-revisium-antivirus.png

#/usr/local/mgr5/sbin/mgrctl -m ispmgr exit;

echo "Revisium Antivirus has been uninstalled. Chao!"