#!/bin/bash

ROOT=`pwd`

if [ "${ROOT}" == "/" ]; then
    echo "Cannot be executed in the root folder."
    exit;
fi

if ! [ -f "${ROOT}/install.sh" ]; then
    echo "Cannot find install.sh. Please, ensure that you are in the ${ROOT}"
    exit;
fi

if [ -d usr/ ]; then
    cp -r usr/* /usr
fi

if [ -d etc/ ]; then
    cp -r etc/* /etc
fi

if [ -f etc/cron.d/revisium ]; then
    cp etc/cron.d/revisium /etc/cron.d/revisium
fi

mkdir /usr/local/mgr5/var/ra_data/

mkdir           /usr/local/mgr5/var/scafore/
mkdir           /usr/local/mgr5/var/scafore/log
mkdir -m=777    /usr/local/mgr5/var/scafore/tmp
mkdir -m=777    /usr/local/mgr5/var/scafore/result
mkdir           /usr/local/mgr5/var/scafore/backups
mkdir           /usr/local/mgr5/var/scafore/configs
mkdir           /usr/local/mgr5/var/scafore/cache
mkdir           /usr/local/mgr5/var/scafore/cache/queue
mkdir           /usr/local/mgr5/var/scafore/cache/sessions
mkdir           /usr/local/mgr5/var/scafore/cache/tasks

ps ax | grep "scafore/queue.php" | grep -v "grep" | awk '{system("kill -9 " $1)}'

php /usr/local/mgr5/addon/revisium_antivirus/services/sync_params.php

/usr/local/mgr5/sbin/mgrctl -m ispmgr exit;

echo "Revisium Antivirus installed. Open the ISP Manager and check it under Revisium Antivirus menu" 