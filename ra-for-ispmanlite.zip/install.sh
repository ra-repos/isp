#!/bin/bash

ROOT=`pwd`

if [ "${ROOT}" == "/" ]; then
    echo "Cannot be executed in the root folder."
    exit;
fi

cp -rf usr/* /usr
cp -rf etc/* /etc
cp -f etc/cron.d/revisium /etc/cron.d/revisium

mkdir -p /usr/local/mgr5/var/ra_data/

mkdir -p           /usr/local/mgr5/var/scafore/
mkdir -p           /usr/local/mgr5/var/scafore/log
mkdir -p -m=777    /usr/local/mgr5/var/scafore/tmp
mkdir -p -m=777    /usr/local/mgr5/var/scafore/result
mkdir -p           /usr/local/mgr5/var/scafore/backups
mkdir -p           /usr/local/mgr5/var/scafore/configs
mkdir -p           /usr/local/mgr5/var/scafore/cache
mkdir -p           /usr/local/mgr5/var/scafore/cache/queue
mkdir -p           /usr/local/mgr5/var/scafore/cache/sessions
mkdir -p           /usr/local/mgr5/var/scafore/cache/tasks

ps ax | grep "scafore/queue.php" | grep -v "grep" | awk '{system("kill -9 " $1)}'

php /usr/local/mgr5/addon/revisium_antivirus/services/sync_params.php

/usr/local/mgr5/sbin/mgrctl -m ispmgr exit;

echo "Revisium Antivirus has been installed. Open the ISP Manager and check it under Revisium Antivirus menu" 