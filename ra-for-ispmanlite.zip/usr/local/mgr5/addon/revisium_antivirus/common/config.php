<?php

// in /etc/cron.d/revisium need same run options

define('RA_PHP_HANDLER', '/opt/php71/bin/php'); 
define('RA_PHP_INI'    , __DIR__ . '/php.ini');