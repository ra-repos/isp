<?php

define('LICENSE_KEY', '');

define('SCAFORE_UPDATE', '');

define('PROCU_LOGDIR'           , '/usr/local/mgr5/var/scafore/log');
define('PROCU_TMPDIR'           , '/usr/local/mgr5/var/scafore/tmp');
define('PROCU_CACHE'            , '/usr/local/mgr5/var/scafore/cache');
define('PROCU_RESULTSDIR'       , '/usr/local/mgr5/var/scafore/result');
define('PROCU_BACKUPDIR'        , '/usr/local/mgr5/var/scafore/backups');
define('PROCU_CONFIGS'          , '/usr/local/mgr5/var/scafore/configs');

define('QUEUE_COUNT_SLOT', 2);

prj_define('ERROR_LANG', 'ru');